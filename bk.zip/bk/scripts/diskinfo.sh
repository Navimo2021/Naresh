#!/bin/bash
for i in $(omreport storage controller |grep "^ID" |awk '{print $3}'); do omreport storage pdisk controller=$i |egrep "Media|Capacity|Serial No"; done
