#!/bin/bash
> /tmp/inventory-info.txt
> /tmp/nfsip
chmod 777 /tmp/inventory-info.txt
mon=$(date +'%b')
day=$(date +'%d')
DATE=$(date +%F)
Uptime=`uptime | awk '{print $3,$4}' | cut -d "," -f 1`
Hostname=`hostname`
osv=`grep -o '[A-Z\/0-9/\.]' /etc/redhat-release | tr -d '\n'| rev | cut -c2- | rev`
hwtype=$(/usr/sbin/dmidecode -t 1 | grep Manufacturer | awk -F ':' '{print $2}')
Socket=$(lscpu |grep -i socket |tail -1 |awk '{print $2}')
Core=$(lscpu |grep -i socket |head -1 |awk '{print $4}')
Mem=$(free -h |grep -i mem |awk '{print $2}')
Swap=$(free -h |grep -i swap |awk '{print $2}')
SN=$(/usr/sbin/dmidecode -t 1 |grep -i serial |awk '{print $3}')
Prodip=$(nslookup `hostname` |tail -2 |grep -i ad |awk '{print $2}')
Gatewayip=$(netstat -nr |grep -i ug |awk '{print $2}')
Backupip=$(/usr/sbin/ip a |grep "/17" |awk '{print $2}'| rev | cut -c 4- | rev)
sleep 2s
filer=$(df -ThP |grep nfs |cut -d ':' -f 1 |sort |uniq)
echo "<tr>"
echo "<td>$DATE</td>"
echo "<td>$Hostname</td>"
echo "<td>$osv</td>"
echo "<td>$Uptime</td>"
echo "<td>$hwtype</td>"
echo "<td>$Socket</td>"
echo "<td>$Core</td>"
echo "<td>$Mem</td>"
echo "<td>$Swap</td>"
echo "<td>$SN</td>"
echo "<td>$Prodip</td>"
echo "<td>$Gatewayip</td>"
if [ -z "$Backupip" ]
then
    echo "<td>No Backup IP</td>"
else
    echo "<td>$Backupip</td>"
fi
if [ -z "$filer" ]
then
    echo "No NFS file system" >> /tmp/nfsip
else
for i in $filer; do
    filerip=$(/usr/bin/grep $i /etc/hosts |grep -v "^#" |awk '{print $1}' |uniq)
    nfsip=$(/usr/sbin/ip r g $filerip |grep -oP 'src \K\S+' >> /tmp/nfsip);done
fi
Nfsclient=$(cat /tmp/nfsip|sort|uniq)
echo "<td>$Nfsclient</td>"
echo "</tr>"
