#!/bin/bash
> /tmp/bkp-vmdk-check.txt
chmod 777 /tmp/bkp-vmdk-check.txt
mon=$(date +'%b')
day=$(date +'%d')
Uptime=`uptime | awk '{print $3,$4}' | cut -d "," -f 1`
Hostname=`hostname`

PVOLUME=`/usr/sbin/pvs |grep /dev |awk '{print $1}'`
SCSI=`lsscsi |awk '{print $7}' |grep /dev`
lOGICAL=`/usr/sbin/lvs -ao +devices |awk '{print $5}' |cut -d "(" -f 1 |grep /dev |uniq`
LVMDISKSCAN=`/usr/sbin/lvmdiskscan |grep /dev |awk '{print $1}'`

echo "<tr>"
echo "<td>$Hostname</td>"
echo "<td>$Uptime</td>"
echo "<td>$PVOLUME</td>"
echo "<td>$SCSI</td>"
echo "<td>$lOGICAL</td>"
echo "<td>$LVMDISKSCAN</td>"
echo "</tr>"
