##/bin/bash

  release=$(subscription-manager release|awk '{print $2}')

  sapaddon=$(grep ADDON=SAP /var/log/puppet_configgroups.txt|wc -l)

  if [[ "$release" == "8.8" || "$release" == "8.6" || "$release" == "8.4" ]] ; then
    subscription-manager repos --enable=codeready-builder-for-rhel-8-x86_64-eus-rpms
    subscription-manager repos --enable=rhel-8-for-x86_64-supplementary-eus-rpms
    if [[ "$sapaddon" == 1 ]] ; then
      subscription-manager repos --enable=rhel-8-for-x86_64-appstream-e4s-rpms
      subscription-manager repos --enable=rhel-8-for-x86_64-baseos-e4s-rpms
      subscription-manager repos --enable=rhel-8-for-x86_64-sap-netweaver-e4s-rpms
      subscription-manager repos --enable=rhel-8-for-x86_64-sap-solutions-e4s-rpms
    else
      subscription-manager repos --enable=rhel-8-for-x86_64-baseos-eus-rpms
      subscription-manager repos --enable=rhel-8-for-x86_64-appstream-eus-rpms
    fi
  fi
