#!/bin/bash

###20Jul2016###
# * Capturing OS details
# * Configuration files backup
# * Mount Point Validation
# * System services validation
# * Selinux check
# * Memory value check
# * Hardware Validation
# * timezone

#####09Aug2016######
# * Merged compare script to this

#####19Aug2016######
# * Excluded access.conf backup files and created another cp only for access.conf
# * Added grub.conf backup for RHEL7

#####30Aug2016######
# * separated OSconfig files backup specifi to RHEL7 & RHEL5/6

#####13Oct2016######
# * Added checklist for IP addresses

#####30JAN2017######
# IP Check - Need to work
# HW Info - Need to just display on webpage
# Change echo command to use file output


user=`who am i | awk '{print $1}'`;

export PATH=/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/sbin

case `uname` in
Linux)
                      #echo -en "Server is running with `uname` , Backup will be taken care\n"
                      ;;
SunOS)
                      echo -en "<td>Server is running with `uname` , Please do manual backup</td>"
                      exit;;
AIX)
                      echo -en "<td>Server is running with `uname` , Please do manual backup</td>"
                      exit;;
*)
                      echo -en "<td>Please check the OS and do backup</td>"
                      exit;;
esac





#####Variable definitions ######

OSRelease=$(cat /etc/redhat-release | awk '{print $7}' | awk -F "." '{print $1}')



########OS Details########
OSversion()
{
OSType="$LOGDIR/OSVersion";
Kernel="$LOGDIR/kernel";
cpuinfo="$LOGDIR/cpuinfo";
grep -c processor /proc/cpuinfo |tee $cpuinfo $LOG_DIR/cpu > /dev/null
uname -a > $Kernel
uname -r > $LOG_DIR/kernelversion
meminfo
echo "<td>`cat /etc/redhat-release |tee -a $OSType`</td>"
echo "<td>`uname -r`</td>"
echo "<td>`cat $cpuinfo`</td>"
echo "<td>$mem_val</td>"
}

LinuxHealth()
{
##### load average #####
echo "<td>`uptime | awk '{print $10, $11, $12}'`</td>"
##### CPU free #####
echo "<td>`iostat | awk 'NR==4 {print $6}'`</td>"
##### SWAP used #####
echo "<td>`free -m | grep Swap | while read output; do T=$(echo $output | awk '{print $2}'| sed 's/k//'); U=$(echo $output | awk '{print $3}'| sed 's/k//'); A=$(echo $output | awk '{print $4}'| sed 's/k//'); TS=\`expr $U+$A | bc\`; echo -e "\n================================\nTotal : $T"; echo "Available : $A"; echo "Used : $U"; P=\`echo "scale=5; ($U/$TS)*100" | bc -l\`; echo -e "Swap utilization is at $P\n================================ \n"; done | awk 'NR==6 {print $5}'`</td>"
##### Memory Used #####
echo "<td>`free -m | grep Mem |while read output; do T=$(echo $output | awk '{print $2}'| sed 's/k//'); U=$(echo $output | awk '{print $3}'| sed 's/k//'); A=$(echo $output | awk '{print $4}'| sed 's/k//'); TS=\`expr $U+$A | bc\`; echo -e "\n================================\nTotal : $T"; echo "Available : $A"; echo "Used : $U"; P=\`echo "scale=5; ($U/$TS)*100" | bc -l\`; echo -e "Swap utilization is at $P\n================================ \n"; done | awk 'NR==6 {print $5}'`</td>"
}

itmrestartcheck()
{
echo "<td>`ps -eo pcpu,pid,user,args | sort -k 1 -r | sed 's/%//'| head -5`</td>"
}


cpuused()
{
echo "<td>`ps -eo pcpu,pid,user,args | sort -k 1 -r | sed 's/%//'| head -5`</td>"
}

memoryused()
{
echo "<td>`ps -eo user,comm,pid,ppid,%mem | sort -k 5 -r| sed 's/%//'| head -5`</td>"
}

nfsnotresponding()
{
cat /var/log/messages | grep -i nfs | grep -i responding > nfsnotresponding.txt
     if [ ! -s nfsnotresponding.txt ]; then
            printf "<td align=\"center\">No NFS not responding error Found</td>"
        else
            printf "<td align=\"center\"><font color=\"red\">$(cat nfsnotresponding.txt)</font></td>"
        fi
}

multipathcheck()
{

/usr/sbin/multipath -ll | grep -e failed -e faulty > multipathcheck.txt
     if [ ! -s multipathcheck.txt ]; then
            printf "<td align=\"center\">No Faulty Multipath found</td>"
        else
            printf "<td align=\"center\"><font color=\"red\">$(cat multipathcheck.txt)</font></td>"
        fi
}

teambondmodecheck()
{
/sbin/ifconfig -a | grep -i team | awk '{ print $1 }' | cut -d ":" -f 1 > teamresult.txt

if [ -s teamresult.txt ]
then
  for i in `cat  teamresult.txt`
  do
    var1=$(/bin/teamdctl $i state | grep -i runner | awk '{print $2}')
    printf "<td>$i</td>"
    printf "<td>$var1</td>"
  done
else
  printf "<td>No Team/bond</td>"
  printf "<td>No Team/bond</td>"
fi
}



diskusagecheck()
{
totaldisk=`df -k | egrep -v "tmpfs|devtmpfs|1K-block" | awk '{print $2}' | sort -nr | sed '/^$/d' | paste -sd+ | bc`
useddisk=`df -k | egrep -v "tmpfs|devtmpfs|Used" | awk '{print $3}' | sort -nr | sed '/^$/d' | paste -sd+ | bc`
osversion=`cat /etc/redhat-release`
servertype=`dmidecode | grep -A3 '^System Information' | grep -e "Manufacturer" | awk {'print $2'}`
echo "<td>$totaldisk</td>"
echo "<td>$useddisk</td>"
echo "<td>$osversion</td>"
echo "<td>$servertype</td>"
}

ldapcheck() 
{
case $OSRelease in
5|6)###RHEL 5/6 Check###
      ldapservstat=`service dirsrv status | egrep "running"`
         if [ -z "$ldapservstat" ]
         then
            echo "<td>Not Running</td>"
         else
            echo "<td>Running</td>"     
         fi

      connections=`lsof -i :389 | egrep "(ESTABLISHED)" | wc -l`
      cpuusge=`ps aux | grep "ns-slapd" | grep -v grep | awk '{print $3}'`
        echo "<td>$cpuusge</td>"
        echo "<td>$connections</td>"
        ;;
7)###RHEL 7 Check###
        ldapservstat=`systemctl list-units --type service | egrep "dirsrv@" | egrep "running"`
         if [ -z "$ldapservstat" ]
         then
            echo "<td>Not Running</td>"
         else
            echo "<td>Running</td>"     
         fi

      connections=`lsof -i :389 | egrep "(ESTABLISHED)" | wc -l`
      cpuusge=`ps aux | grep "ns-slapd" | grep -v grep | awk '{print $3}'`
        echo "<td>$cpuusge</td>"
        echo "<td>$connections</td>"
        ;;
*)
        echo "Not recognized Redhat OS"
        ;;
esac
}


networkcheck()
{
gateway=$(/sbin/ip route | awk '/default/ { print $3 }')
dns=$(cat /etc/resolv.conf | awk '/nameserver/ {print $2}' | awk 'NR == 1 {print; exit}')
if ping -q -c 1 -W 1 $gateway >/dev/null; then
     printf "<td align=\"center\">Network UP</td>"
else
     printf "<td align=\"center\"><font color=\"red\">Gateway Not Rechable</td>"
fi
##### NIC IP/NETMASK ########
osrelease=$(cat /etc/redhat-release | awk '{print $7}' | awk -F "." '{print $1}')
case $osrelease in
5|6)
     printf "<td align=\"center\">"
     for i in `ifconfig | grep -e HWaddr | awk '{print $1}'`;
     do
       ifconfig $i| grep -e Mask | awk '{print  $2, $4}' > ipverify.txt
       if [ ! -s ipverify.txt ]; then
            printf "<font color=\"red\">$i ---> No IP/Netmask configured </font><br/>"
       else
            printf "$i ---> $(ifconfig $i| grep -e Mask | awk '{print  $2, $4}') <br/>"
       fi
     done
     printf "</td>"
     printf "<br/>"
     printf "<td align=\"center\">"
     for j in `ifconfig | grep -e HWaddr | awk '{print $1}'`;
     do
      printf "$j ---> $(ifconfig $j | grep -e errors | awk '{print $1, $3, $4}') <br/>"
     done
     printf "</td>"
     ;;
7)
     printf "<td align=\"center\">"
     for i in `ifconfig | grep -e mtu | awk '{print $1}' | tr -d ':'`;
     do
       ifconfig $i | grep -e netmask|  awk '{print  $1, $2, $3, $4}' > ipverify.txt
       if [ ! -s ipverify.txt ]; then
            printf "<font color=\"red\">$i ---> No IP/Netmask configured </font><br/>"
       else
            printf "$i ---> $(ifconfig $i | grep -e netmask|  awk '{print  $1, $2, $3, $4}') <br/>"
       fi
     done
     printf "</td>"
     printf "<br/>"
      printf "<td align=\"center\">"
     for j in `ifconfig | grep -e mtu | awk '{print $1}'| tr -d ':'`;
     do
      printf "$j ---> $(ifconfig $j | grep -e errors | awk '{print $1, $2, $3, $4, $5}') <br/>"
     done
     printf "</td>"
     ;;
*)
        echo -en "<td>Please Check OS version </td>"
        ;;
esac

############################
echo "<td>`/sbin/ip route | awk '/default/ { print $3 }'`</td>"
if ping -q -c 1 -W 1 $dns >/dev/null; then
     printf "<td align=\"center\">$dns Rechable</td>"
else
     printf "<td align=\"center\"><font color=\"red\">$dns Not Rechable</td>"
fi
cat /etc/fstab | grep -e nfs | awk -F : '{print $1}' | uniq -u | sed '/^#/ d' > nfsvfiler.txt
        if [ ! -s nfsvfiler.txt ]; then
            printf "<td align=\"center\">No NFS shares mounted</td>"
        else
           printf "<td align=\"center\">"
           for i in `cat /etc/fstab | grep -e nfs | awk -F : '{print $1}' | uniq -u | sed '/^#/ d'`;
           do
             if ping -q -c 1 -W 1 $i >/dev/null; then
                printf "$i - OK<br/>"
             else
                printf "$i Not Rechable<br/>"
             fi
           done
           printf "</td>\n"
        fi
######### BONDING / TEAMING ##########
ifconfig | grep -e bond -e team | awk '{print $1}' > bondteam.txt
        if [ ! -s bondteam.txt ]; then
            printf "<td align=\"center\">No Bonding/Teaming configured</td>"
        else
           printf "<td>"
           for i in `ifconfig | grep -e bond -e team | awk '{print $1}'`;
           do
             printf "$i --> $(cat /proc/net/bonding/$i |grep -e Mode -e "Primary Slave" -e "Slave Interface")"
             printf "<br/>"
           done
           printf "</td>\n"
        fi   

#####################################
##########ILO/IDRAC IP###############

case $(dmidecode | grep -A3 '^System Information' | grep -e "Manufacturer" | awk {'print $2'}) in
HP)
   echo "<td>`hponcfg -w iLO_ouput.out >ilooutput.txt && cat iLO_ouput.out | grep -e IP_ADDRESS | awk 'NR==1 {print $4}' |tr -d "\"/>"`</td>";
   ;;
Dell)
   echo "<td>`racadm getniccfg | grep -e "Static IP Address" | awk 'NR==1 {print $5}'`</td>";
   ;;
VMware,)
   echo "<td>Vmware-server</td>";
   ;;
*)
   echo "<td>solaris/aix/cloud server<td>";
   ;;
esac

#####################################
}

nfscheck()
{
cat /proc/mounts | grep -i nfs | grep -e addr | rev | egrep -o '^[^=]+' | awk '{print $3}' | rev | uniq > /tmp/nfs-filer-ip.txt
for i in `sort /tmp/nfs-filer-ip.txt | uniq`
do
    echo "<tr>"
    echo "<td></td>"
    source=`/sbin/ip route get $i | grep -i src  | sed 's/\(.*\)\(src*\)/\2/g' | awk '{print $2}'`
    echo "<td> $source </td>" 
    echo "<td> $i </td>"
    shares=`cat /proc/mounts | grep -i nfs | grep -e $i | egrep -o '^[^ ]+'`
    echo "<td> $shares </td>"
    echo "</tr>"
done
}

lastrebootcheck()
{
lastreboot1=`/usr/bin/who -b | awk '{print $3,$4}'`
echo "<td> $lastreboot1 </td>"
}

lastpatchcheck()
{
lastpatch=`rpm -qa --last | grep kernel | awk 'NR==1{print $3,$4,$5}'`
echo "<td>$lastpatch</td>"
}


hbacardcheck()
{
grep -v "zZzZ" /sys/class/scsi_host/host*/model_name | awk -F '/|:' '{print $5, $7}' > /tmp/modelname.txt
grep -v "zZzZ" /sys/class/fc_host/host*/speed | awk -F '/|:' '{print $5, $7}' > /tmp/speed.txt
grep -v "zZzZ" /sys/class/scsi_host/host*/link_state | awk -F '/|:' '{print $5, $7}' > /tmp/linkstate.txt
grep -v "zZzZ" /sys/class/scsi_host/host*/driver_version | awk -F '/|:' '{print $5, $7}' > /tmp/driverversion.txt
grep -v "zZzZ" /sys/class/scsi_host/host*/fw_version | awk -F '/|:' '{print $5, $7}' > /tmp/fwversion.txt
grep -v "zZzZ" /sys/class/fc_host/host*/port_name | awk -F '/|:' '{print $5, $7}' > /tmp/wwnno.txt

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/modelname.txt
echo "</td>"

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/speed.txt
echo "</td>"

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/linkstate.txt
echo "</td>"

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/driverversion.txt
echo "</td>"

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/fwversion.txt
echo "</td>"

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/wwnno.txt
echo "</td>"

}




noofkernelscheck()
{
nkernels=`/bin/rpm -q kernel | wc -l`
#/bin/rpm -q kernel > /tmp/kernellist.txt
/bin/rpm -qa --last | grep -i kernel-[1-9] > /tmp/kernellist.txt
echo "<td>$nkernels</td>"

echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/kernellist.txt
       echo "</td>"
}



mirroredlvcheck()
{
mirrlv=`/usr/sbin/lvs | fgrep "mw" | awk '{print "LV:" $1 "| VG:" $2 "| SIZE:" $4}'`
/usr/sbin/lvs | fgrep "mw" | awk '{print "LV:" $1 "| VG:" $2 "| SIZE:" $4}' > /tmp/mirroredlv.txt
if [ -z "$mirrlv" ]
then
      echo "<td>No Mirrred LV's found</td>"
else
       echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line" 
     done < /tmp/mirroredlv.txt
       echo "</td>"
fi
}

multipathcheck1()
{
activepaths=`/bin/echo 'show multipaths status' | /sbin/multipathd -k | egrep -v "multipathd"`
/bin/echo 'show multipaths status' | /sbin/multipathd -k | egrep -v "multipathd"> /tmp/activemultipaths.txt
if [ -z "$activepaths" ]
then
      echo "<td>Multipath Not configured</td>"
      echo "<td>Multipath Not configured</td>"
else
       /usr/sbin/multipath -ll | grep -e failed -e faulty > multipathcheck.txt
     if [ ! -s multipathcheck.txt ]; then
            printf "<td align=\"center\">No Faulty Multipath found</td>"
        else
            printf "<td align=\"center\"><font color=\"red\">$(cat multipathcheck.txt)</font></td>"
        fi
     echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < /tmp/activemultipaths.txt
       echo "</td>"
fi
}

clusterhealthcheck()
{
activenodes=`/usr/sbin/pcs status | egrep "Online"`
/usr/sbin/pcs resource show > activeresources.txt
/usr/sbin/pcs status | egrep "fence" > activefence.txt
if [ -z "$activenodes" ]
then

     /usr/sbin/clustat | egrep "rgmanager" > clusteractivenodes.txt
     /usr/sbin/clustat | egrep "service" > clustactiveresources.txt
     /usr/sbin/fence_tool ls | egrep "member" > clustactivefence.txt
  
      echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < clusteractivenodes.txt
       echo "</td>"

 
      echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < clustactiveresources.txt
       echo "</td>"
    
    echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < clustactivefence.txt
       echo "</td>"

else
    echo "<td>$activenodes</td>"

      echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < activeresources.txt
       echo "</td>"

    echo "<td>"
     while read -r line;
     do
     echo "<br/>"
     echo "$line"
     done < activefence.txt
       echo "</td>"

fi
}

ensrnocheck()
{
/usr/sbin/hpacucli ctrl all show detail |grep -i array |grep -v Embedded |awk '{print $6}' > /tmp/slot
sleep 5s
for i in `cat /tmp/slot`; do /usr/sbin/hpacucli controller slot=$i  enclosure all show detail |egrep "Enclosure|Serial"; done >/tmp/ensrresult.txt
sleep 5s

if [ -s /tmp/ensrresult.txt ]
then
echo "<td>"
while read -r line;
do
echo "<br/>"
echo "$line"
done < /tmp/ensrresult.txt
echo "</td>"
else
 printf "<td>please check manually</td>"
fi
}



hpphysicaldrivecheck()
{
hppdstatus=`/usr/sbin/hpacucli ctrl all show config | grep -e physicaldrive`
if [ -z "$hppdstatus" ]
then 
     hppdstatus1=`/usr/sbin/hpssacli ctrl all show config | grep -e physicaldrive`
      if [ -z "$hppdstatus1" ]
      then
      hppdstatus2=`/usr/sbin/ssacli ctrl all show config | grep -e physicaldrive`
          if [ -z "$hppdstatus2" ]
          then
            echo "<td>hpacucli/hpasmcli/ssacli commands Not configured</td>"
          else
            /usr/sbin/ssacli ctrl all show config | grep -e physicaldrive > /tmp/hpphysicaldrive.txt
            echo "<td>"
            while read -r line;
            do
             echo "<br/>"
             echo "$line"
             done < /tmp/hpphysicaldrive.txt
            echo "</td>"
          fi
      else
       /usr/sbin/hpssacli ctrl all show config | grep -e physicaldrive > /tmp/hpphysicaldrive.txt
       echo "<td>"
            while read -r line;
            do
             echo "<br/>"
             echo "$line"
             done < /tmp/hpphysicaldrive.txt
            echo "</td>"
      fi
else
/usr/sbin/hpacucli ctrl all show config | grep -e physicaldrive > /tmp/hpphysicaldrive.txt
       echo "<td>"
            while read -r line;
            do
             echo "<br/>"
             echo "$line"
             done < /tmp/hpphysicaldrive.txt
            echo "</td>"   
fi
}


hwhealthcheck()
{
case $(dmidecode | grep -A3 '^System Information' | grep -e "Manufacturer" | awk {'print $2'}) in
HP)
   echo "<td>`hpasmcli -s "show powersupply" | grep -e "Power supply"  -e Condition`</td>";
   echo "<td>`hpasmcli -s "show fans" | awk {'print $1, $3, $4'}`</td>";
   echo "<td>`hpasmcli -s "show dimm" | grep -e Module -e Status`</td>";
   echo "<td>`hpasmcli -s "show server" | grep -e Processor -e Status`</td>";
   echo "<td>`hpacucli ctrl all show config | grep -e physicaldrive`</td>";
   echo "<td>`hpasmcli -s "show temp" | grep -e CPU -e AMBIENT -e MEMORY_BD -e SCSI_BACKPLANE_ZONE`</td>";
   ;;
Dell)
   echo "<td>`/opt/dell/srvadmin/bin/omreport chassis | awk 'NR==9 {print $1}'`</td>";
   echo "<td>`/opt/dell/srvadmin/bin/omreport chassis | awk 'NR==6 {print $1}'`</td>";
   echo "<td>`/opt/dell/srvadmin/bin/omreport chassis | awk 'NR==8 {print $1}'`</td>";
   echo "<td>`/opt/dell/srvadmin/bin/omreport chassis | awk 'NR==11 {print $1}'`</td>";
   echo "<td>`/opt/dell/srvadmin/bin/omreport storage pdisk controller=0 | grep -e Name -e State`</td>";
   echo "<td>`/opt/dell/srvadmin/bin/omreport chassis temps | grep -e Probe -e Status`</td>";
   ;;
VMware)
   echo "<td>Vmware-server</td>";
   echo "<td>Vmware-server</td>";
   echo "<td>Vmware-server</td>";
   echo "<td>Vmware-server</td>";
   echo "<td>Vmware-server</td>";
   echo "<td>Vmware-server</td>";
   ;;
*)
   echo "<td>solaris/aix server<td>";
   echo "<td>solaris/aix server<td>";
   echo "<td>solaris/aix server<td>";
   echo "<td>solaris/aix server<td>";
   echo "<td>solaris/aix server<td>";
   echo "<td>solaris/aix server<td>";
   ;;
esac
}

timezcheck()
{
echo "<td>`date +\"%Z\"`</td>"
case $OSRelease in
5|6)
     echo "<td>`ntpq -p | grep -i \"*\" | awk '{print $1}' | cut -d \"*\" -f2`</td>";
     echo "<td>`ntpq -c rv | grep -i \"rootdelay\" | awk '{print $3}' | cut -d \",\" -f1`</td>";
     echo "<td>`ntpq -c rv | grep -i "leap" | awk 'NR==2{print $3}' | cut -d "," -f1`</td>";
     ;;
7)
     echo "<td>`chronyc tracking | grep -i \"Reference\" | awk '{print $5}' | cut -d \"(\" -f2 | cut -d \")\" -f1`</td>";
     echo "<td>`chronyc tracking | grep -i \"System time\" | cut -d \":\" -f2`</td>";
     echo "<td>`chronyc tracking | grep -i "Leap Status" | cut -d ":" -f2`</td>";
     ;;
*)
        echo -en "<td>Please validate OS version </td>"
        ;;
esac
}

readonlyfilesystem()
{
cat /proc/mounts | grep ro, > /tmp/readonlyfs.txt
        if [ ! -s /tmp/readonlyfs.txt ]; then
            printf "<td align=\"center\">No Read-only File System Found</td>"
        else
            printf "<td align=\"center\"><font color=\"red\">$(cat /tmp/readonlyfs.txt)</font></td>"
        fi
}
######Configuration files backup#########
OSConfigfielsbackup()
{

cp -pr /etc/fstab $LOGDIR;

##-------- OS version check to have backup of RHEL7 ----------------------------------##
case $OSRelease in
5|6)
     cp -pr /boot/grub/grub.conf $LOGDIR;
     ifconfig -a > $LOGDIR/ifconfig-a;
     route -n > $LOGDIR/route;
     service --status-all > $LOGDIR/services ;
     ;;
7)
     cp -pr /boot/grub2/grub.cfg $LOGDIR;
     ip addr show > $LOGDIR/ipaddr;
     ip route show > $LOGDIR/route;
     systemctl --all > $LOGDIR/services ;
     ;;
*)
        echo -en "<td>Please validate OS version </td>"
        ;;
esac
##-----------------------------------------------------------------------------##

cp -pr /etc/sysctl.conf $LOGDIR;
#cp -pr /etc/security $LOGDIR > /dev/null 2>&1 ;
for i in $(ls /etc/security/ | grep -v "access.conf*")
do
mkdir -p $LOGDIR/security
cp -pr /etc/security/$i $LOGDIR/security
done
cp -pr /etc/security/access.conf $LOGDIR/security
cp -pr /etc/sysconfig $LOGDIR;
cp -pr /etc/modprob* $LOGDIR > /dev/null 2>&1 ;
cp -pr /etc/passwd $LOGDIR
cp -pr /etc/group $LOGDIR
cp -pr /etc/shadow $LOGDIR
mount > $LOGDIR/mount
pvs > $LOGDIR/pv
vgs > $LOGDIR/vg
lvs -a -o +devices > $LOGDIR/lvm
lvmdiskscan > $LOGDIR/lvmscan

ps -aux > $LOGDIR/ps 2>&1;
date > $LOGDIR/date
free -m > $LOGDIR/free-m
sysctl -a > $LOGDIR/sysctl-a
rpm -qa > $LOGDIR/rpmpackages
/soe3/bin/soe list > $LOGDIR/soe_list 2>&1 ;
/soe3/bin/soe listlh -v list > $LOGDIR/soe_lh_list 2>&1 ;
}

######Mount Point Validation######
dfcheck()
{
df="$LOGDIR/dfvalue";
dfcomparision="$LOG_DIR/dfcompare"
df -PTh > $df
df -Ph | egrep -v ^Filesystem | awk '{print $1 "\t\t"$6}'| sort -u > $dfcomparision
echo "<td>`cat $dfcomparision | wc -l`</td>"
#printf '%20s\n' | tr ' ' -
#echo -en "\e[1;33;40m Df details \e[0m \n"
#printf '%20s\n' | tr ' ' -
#echo -en "`cat $df`\n\n"
}

######System services validation######
Servicescheck()
{
case $OSRelease in
5|6)###RHEL 5/6 Check###
####Postfix Service Check######
        service postfix status > $LOGDIR/postfix 2>&1
        service postfix status  > /dev/null 2>&1
        if [ $? = 0 ]
        then
        echo "Running" > $LOG_DIR/postfixstatus
        echo "<td>`cat $LOG_DIR/postfixstatus`</td>"
        else
        echo "Not Running" > $LOG_DIR/postfixstatus
        echo "<td>`cat $LOG_DIR/postfixstatus`</td>"
        fi
        #printf '%30s\n' | tr ' ' -;
        #echo -en "\e[1;33;40m Services status \e[0m \n"
        #printf '%30s\n' | tr ' ' -;
        #echo -en "postfix\t\t : \t`cat $LOG_DIR/postfixstatus` \n"
#####Sendmail service check######
        service sendmail status > $LOGDIR/sendmail 2>&1
        service sendmail status  > /dev/null 2>&1
        if [ $? = 0 ]
        then
        echo "Running" > $LOG_DIR/sendmailstatus
        echo "<td>`cat $LOG_DIR/sendmailstatus`</td>"
        else
        echo "Not Running" > $LOG_DIR/sendmailstatus
        echo "<td>`cat $LOG_DIR/sendmailstatus`</td>"
        fi
        #echo -en "sendmail\t : \t`cat $LOG_DIR/sendmailstatus` \n"
######Puppet service check######
        service puppet status > $LOGDIR/puppet 2>&1
        service puppet status  > /dev/null 2>&1
        if [ $? = 0 ]
        then
        echo "Running" > $LOG_DIR/puppetstatus
        echo "<td>`cat $LOG_DIR/puppetstatus`</td>"
        else
        echo "Not Running" > $LOG_DIR/puppetstatus
        echo "<td>`cat $LOG_DIR/puppetstatus`</td>"
        fi
        #echo -en "puppet\t\t : \t`cat $LOG_DIR/puppetstatus` \n"
        ;;
7) ###RHEL 7 checks###
####Postfix Service Check######
       systemctl status postfix > $LOGDIR/postfix 2>&1
       ps -ef | grep -i postfix | grep -v grep   > /dev/null 2>&1
        if [ $? = 0 ]
        then
        echo "Running" > $LOG_DIR/postfixstatus
        echo "<td>`cat $LOG_DIR/postfixstatus`</td>"
        else
        echo "Not Running" > $LOG_DIR/postfixstatus
        echo "<td>`cat $LOG_DIR/postfixstatus`</td>"
        fi
        #printf '%30s\n' | tr ' ' -;
        #echo -en "\e[1;33;40m Services status \e[0m \n"
        #printf '%30s\n' | tr ' ' -;
        #echo -en "postfix\t\t : \t`cat $LOG_DIR/postfixstatus` \n"
#####Sendmail service check######
        systemctl status sendmail > $LOGDIR/sendmail 2>&1
        ps -ef | grep -i sendmail | grep -v grep   > /dev/null 2>&1
        if [ $? = 0 ]
        then
        echo "Running" > $LOG_DIR/sendmailstatus
        echo "<td>`cat $LOG_DIR/sendmailstatus`</td>"
        else
        echo "Not Running" > $LOG_DIR/sendmailstatus
        echo "<td>`cat $LOG_DIR/sendmailstatus`</td>"
        fi
        #echo -en "sendmail\t : \t`cat $LOG_DIR/sendmailstatus` \n"
######Puppet Service check#####
        systemctl status puppet > $LOGDIR/sendmail 2>&1
        ps -ef | grep -i puppet |  grep -v grep  > /dev/null 2>&1
        if [ $? = 0 ]
        then
        echo "Running" > $LOG_DIR/puppetstatus
        echo "<td>`cat $LOG_DIR/puppetstatus`</td>"
        else
        echo "Not Running" > $LOG_DIR/puppetstatus
        echo "<td>`cat $LOG_DIR/puppetstatus`</td>"
        fi
        #echo -en "puppet\t\t : \t`cat $LOG_DIR/puppetstatus` \n"
        ;;
*)
        echo -en "<td>Please validate OS version </td>"
        ;;
esac
}

selinux()
{
sestatus > $LOGDIR/selilnux
getenforce >$LOG_DIR/selinuxstatus
echo "<td>`cat $LOG_DIR/selinuxstatus`</td>"
#echo -en "selinux\t\t : \t`cat $LOG_DIR/selinuxstatus` \n"
}

########Memory value check######
meminfo() #New version#
{
         cat /proc/meminfo | grep -E MemTotal | awk {'print $2'} | tr -d "[:blank:]" > /tmp/mem_temp;
         expr `cat /tmp/mem_temp` / 1024 / 1024 |tee /tmp/mem_temp1 $LOG_DIR/memory > /dev/null;
         sed -i 's/$/G/g' /tmp/mem_temp1
         mem_val=`cat /tmp/mem_temp1`
}

SOEID_IP_Check() #New version#
{
case $OSRelease in
5|6)###RHEL 5/6 Check###
        for i in `ifconfig | awk  '$1 ~ /eth([0-9]|[0-9]:[0-9])|bond([0-9])/{print $1}'`
        do
             echo " $i : `ifconfig $i | sort -u | awk '/inet addr:/{print $2}' | awk -F : '{print $2}'`"
        done > $LOG_DIR/SOEIDIP_Compare
	echo "<td>`cat $LOG_DIR/SOEIDIP_Compare | wc -l` IPs / "
        ;;
7)###RHEL 7 Check###
        for i in `ifconfig | awk  '$1 ~ /eth([0-9]|[0-9]:[0-9])|team([0-9])/{print $1}' | cut -d : -f1`
        do
             echo " $i : `ifconfig $i | sort -u | awk '/inet /{print $2}'`"
        done > $LOG_DIR/SOEIDIP_Compare
	echo "<td>`cat $LOG_DIR/SOEIDIP_Compare | wc -l` IPs / "
        ;;
*)
        echo "<td>Not recognized OS please take backup manually.</td>"
        ;;
esac
}

###MAC Address check####

HWADDR_Check() #New version#
{
case $OSRelease in
5|6)###RHEL 5/6 Check###
	for i in `ifconfig | awk  '$1 ~ /eth([0-9]|[0-9]:[0-9])|bond([0-9])/{print $1}'`
	do
	     echo " $i : `ifconfig $i | sort -u | grep -o -E '([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}'`"
	done > $LOG_DIR/hwaddrcompare
	echo "`cat $LOG_DIR/hwaddrcompare | wc -l` MAC IDs</td>"
	;;
7)###RHEL 7 Check###
	for i in `ifconfig | awk  '$1 ~ /eth([0-9]|[0-9]:[0-9])|team([0-9])/{print $1}' | cut -d : -f1`
	do
	     echo " $i : `ifconfig $i | sort -u | awk '/ether/ { print $2}'`"
        done > $LOG_DIR/hwaddrcompare
	echo "`cat $LOG_DIR/hwaddrcompare | wc -l` MAC IDs</td>"
	;;
*)
	#echo "Not recognized OS please take backup manually."
 	;;
esac
}

#######Hardware Validation########
Hardware_details()
{
 HW=`dmidecode | grep -i prod`
 #PrintLine
 #echo -en "\e[1;33;40mHardware Details :- \e[0m \n $HW \n\n"
 #PrintLine
}

timezone()
{
date | awk '{print $5}' > $LOG_DIR/tz
echo "<td>`cat $LOG_DIR/tz`</td>"
}


hostnamecheck()
{
hostname > $LOG_DIR/hostnamecheck
echo "<td>`cat $LOG_DIR/hostnamecheck`</td>"
}


####Clean up of old Change details#####
cleanup()
{
#rm -rf /home/logs/CRQ*
find /home/logs/ -name 'CRQ*' -mtime +10 > /tmp/logsummary
if [ `cat /tmp/logsummary | wc -l` -ge 3 ]
then
#echo -en "Doing Cleanup of following old dirs \n `cat /tmp/logsummary` \n"
for i in `cat /tmp/logsummary`
do
rm -r $i
done
fi
}


#-------------------------------------------------------------------------------------------------------------------------------

##################Addition of compare script in this script itself##############################################

#-------------------------------------------------------------------------------------------------------------------------------
compare()
{

PRE_DIR="/home/logs/$chq-`hostname`/pre/$chq"
POST_DIR="/home/logs/$chq-`hostname`/post/$chq"

postfixcompare()
{
diff -b --ignore-all-space "$PRE_DIR"/postfixstatus $POST_DIR/postfixstatus 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nPostfix : Pass  (`cat $POST_DIR/postfixstatus`)\n"
echo "<td>Pass (`cat $POST_DIR/postfixstatus`)</td>"
else
#echo -en "\033[1;31m\nPostfix : Fail\033[0m\n"
echo "<td><font color=\"red\"><b>Fail </b></font> <font color=\"red\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/postfixstatus $POST_DIR/postfixstatus`"
echo ")"
echo "</font></td>"
fi
}

sendmailcompare()
{
diff -b --ignore-all-space "$PRE_DIR"/sendmailstatus $POST_DIR/sendmailstatus 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nSendmail : Pass  (`cat $POST_DIR/sendmailstatus`)\n"
echo "<td>Pass (`cat $POST_DIR/sendmailstatus`)</td>"
else
#echo -en "\033[1;31m\nSendmail : Fail\033[0m\n"
echo "<td><font color=\"red\"><b>Fail </b></font> <font color=\"red\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/sendmailstatus $POST_DIR/sendmailstatus`"
echo ")"
echo "</font></td>"
fi
}


puppetcompare()
{
diff -b --ignore-all-space "$PRE_DIR"/puppetstatus $POST_DIR/puppetstatus 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nPuppet : Pass  (`cat $POST_DIR/puppetstatus`)\n"
echo "<td>Pass (`cat $POST_DIR/puppetstatus`)</td>"
else
##echo -en "\033[1;31m\nPuppet : Fail\033[0m\n"
#echo -n "Puppet : Fail "
#diff -by --ignore-all-space "$PRE_DIR"/puppetstatus $POST_DIR/puppetstatus
echo "<td><font color=\"red\"><b>Fail </b></font> <font color=\"red\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/puppetstatus $POST_DIR/puppetstatus`"
echo ")"
echo "</font></td>"
fi
}

selinuxcompare()
{
diff -b --ignore-all-space "$PRE_DIR"/selinuxstatus $POST_DIR/selinuxstatus 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nSelinux : Pass  (`cat $POST_DIR/selinuxstatus`)\n"
echo "<td>Pass (`cat $POST_DIR/selinuxstatus`)</td>"
else
#echo -en "\033[1;31m\nSelinux : Fail\033[0m\n"
echo "<td><font color=\"red\"><b>Fail </b></font> <font color=\"red\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/selinuxstatus $POST_DIR/selinuxstatus`"
echo ")"
echo "</font></td>"
fi
}

dfcompare()
{
countlocal1=`diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep "<" | wc -l`
countlocal2=`diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep ">" | wc -l`
        if [[ "$countlocal1" != 0 ]] && [[ "$countlocal2" = 0 ]] ; then
                ##echo -en "\033[1;31m\nMounted filesystem check\t:\tFail \033[0m\n"
                ##echo -en "\033[1;31m\n Following local mounts points are missing \033[0m\n"
                #echo -n "Mounted FS Check : Fail ( mounts points missing ) "
                #diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep "<"  | sed ':a;N;$!ba;s/\n/ /g'
                echo "<td><font color=\"red\"><b>Fail</b></font> <font color=\"red\">(mounts points missing) <br>"
                diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep "<"  | sed ':a;N;$!ba;s/\n/ /g'
                echo "</font></td>"
        elif [[ "$countlocal1" = 0 ]] && [[ "$countlocal2" != 0 ]]; then
                ##echo -en "\nMounted  filesystem check\t:\tPass\n"
                ##echo -en "\033[1;32m\nThe following additional mount points are mounted after the activity \033[0m\n"
                #echo -n "Mounted FS Check : Pass ( additional mount points ) "
                #diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep ">" | sed ':a;N;$!ba;s/\n/ /g'
                echo "<td><font color=\"blue\"><b>Pass</b></font> <font color=\"blue\">(additional mount points) <br>"
                diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep ">" | sed ':a;N;$!ba;s/\n/ /g'
                echo "</font></td>"
        elif [[ "$countlocal1" != 0 ]] && [[ "$countlocal2" != 0 ]]; then
                #echo -en "\033[1;31m\nMounted filesystem check\t:\tFail \033[0m\n"
                #echo -en "\033[1;31m\n Following local mounts points are missing \033[0m\n"
                echo "<td><font color=\"red\"><b>Fail</b></font> <font color=\"red\"> (mounts points missing) <br>"
                echo "`diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep "<"  | sed ':a;N;$!ba;s/\n/ /g'`<br>"
                #echo -en "\033[1;32m\nThe following additional mount points are mounted after the activity \033[0m\n"
                echo "additional mount points: <br>"
                diff -b --ignore-all-space "$PRE_DIR"/dfcompare "$POST_DIR"/dfcompare | grep ">" | sed ':a;N;$!ba;s/\n/ /g'
                echo "</font></td>"
        else
                #echo -en "\nMounted local filesystem check\t:\tPass\n"
                echo "<td>Pass</td>"

        fi
}

tzcompare()
{
diff -b --ignore-all-space "$PRE_DIR"/tz "$POST_DIR"/tz 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nTimezone : Pass  (`cat $POST_DIR/tz`)\n"
echo "<td>Pass (`cat $POST_DIR/tz`)</td>"
else
#echo -en "\033[1;31m\nTimezone : Fail\033[0m\n"
echo "<td><font color=\"red\"><b>Fail </b></font> <font color=\"red\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/tz "$POST_DIR"/tz`"
echo ")"
echo "</font></td>"
fi
}

hostnamecompare()
{
diff -b --ignore-all-space "$PRE_DIR"/hostnamecheck "$POST_DIR"/hostnamecheck 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nHostname : Pass  (`cat $POST_DIR/hostnamecheck`)\n"
echo "<td>Pass (`cat $POST_DIR/hostnamecheck`)</td>"
else
#echo -en "\033[1;31m\nHostname : Fail\033[0m\n"
echo "<td><font color=\"red\"><b>Fail </b></font> <font color=\"red\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/hostnamecheck "$POST_DIR"/hostnamecheck`"
echo ")"
echo "</font></td>"
fi
}

SOEIDIPcompare()
{
IPcount1=`diff -b --ignore-all-space "$PRE_DIR"/SOEIDIP_Compare "$POST_DIR"/SOEIDIP_Compare | grep "<" | wc -l`
IPcount2=`diff -b --ignore-all-space "$PRE_DIR"/SOEIDIP_Compare "$POST_DIR"/SOEIDIP_Compare | grep ">" | wc -l`
if [[ "$IPcount1" != 0 ]] && [[ "$IPcount2" = 0 ]] ; then
                #echo -en "\033[1;31m\nIP Address check\t:\tFail \033[0m\n"
                #echo -en "\033[1;31m\n Following IP address/interfaces are missing \033[0m\n"
                echo "<td><font color=\"red\"><b>Fail</b></font> <font color=\"red\"> (IP address missing)<br>"
                echo "`diff -b --ignore-all-space "$PRE_DIR"/SOEIDIP_Compare "$POST_DIR"/SOEIDIP_Compare | grep "<"` / " | sed ':a;N;$!ba;s/\n/ /g'
		echo "</font><br>"
        elif [[ "$IPcount1" = 0 ]] && [[ "$IPcount2" != 0 ]]; then
                #echo -en "\nIP Address check\t:\tPass\n"
                #echo -en "\033[1;32m\nThe following IP address/interfaces are up after the activity \033[0m\n"
                echo "<td><font color=\"blue\"><b>Pass</b></font> <font color=\"blue\"> (IP address up after the activity)<br>"
                echo "`diff -b --ignore-all-space "$PRE_DIR"/SOEIDIP_Compare "$POST_DIR"/SOEIDIP_Compare | grep ">"` / " | sed ':a;N;$!ba;s/\n/ /g'
		echo "</font><br>"
        elif [[ "$IPcount1" != 0 ]] && [[ "$IPcount2" != 0 ]]; then
                #echo -en "\033[1;31m\nIP Adress check\t:\tFail \033[0m\n"
                #echo -en "\033[1;31m\n Following IP address/interfaces are missing \033[0m\n"
                echo "<td><font color=\"red\"><b>Fail</b></font> <font color=\"red\"> (IP address missing)<br>"
                echo "`diff -b --ignore-all-space "$PRE_DIR"/SOEIDIP_Compare "$POST_DIR"/SOEIDIP_Compare | grep "<"`" | sed ':a;N;$!ba;s/\n/ /g'
                #echo -en "\033[1;32m\nThe following IP address/interfaces are up after the activity \033[0m\n"
                echo "<br>IP address up after the activity: <br>"
                echo "`diff -b --ignore-all-space "$PRE_DIR"/SOEIDIP_Compare "$POST_DIR"/SOEIDIP_Compare | grep ">"` / " | sed ':a;N;$!ba;s/\n/ /g'
		echo "</font><br>"
        else
                #echo -en "\nIP Address check\t:\tPass\n"
                echo "<td>Pass / "

        fi
}

HWaddrcompare()
{
IPcount1=`diff -b --ignore-all-space "$PRE_DIR"/hwaddrcompare "$POST_DIR"/hwaddrcompare | grep "<" | wc -l`
IPcount2=`diff -b --ignore-all-space "$PRE_DIR"/hwaddrcompare "$POST_DIR"/hwaddrcompare | grep ">" | wc -l`
if [[ "$IPcount1" != 0 ]] && [[ "$IPcount2" = 0 ]] ; then
                #echo -en "\033[1;31m\nMAC Address check\t:\tFail \033[0m\n"
                #echo -en "\033[1;31m\n Following interfaces are having different MAC address \033[0m\n"
                echo "<font color=\"red\"><b>Fail</b></font> <font color=\"red\"> (MAC Address missing)<br>"
		diff -b --ignore-all-space "$PRE_DIR"/hwaddrcompare "$POST_DIR"/hwaddrcompare | grep "<" | sed ':a;N;$!ba;s/\n/ /g'
		echo "</font></td>"
        elif [[ "$IPcount1" = 0 ]] && [[ "$IPcount2" != 0 ]]; then
                #echo -en "\nMAC Address check\t:\tPass\n"
                #echo -en "\033[1;32m\nThe following interfaces are up after the activity \033[0m\n"
                echo "<font color=\"blue\"><b>Pass</b></font> <font color=\"blue\"> (Interfaces up after the activity)<br>"
		diff -b --ignore-all-space "$PRE_DIR"/hwaddrcompare "$POST_DIR"/hwaddrcompare | grep ">" | sed ':a;N;$!ba;s/\n/ /g'
		echo "</font></td>" 
        elif [[ "$IPcount1" != 0 ]] && [[ "$IPcount2" != 0 ]]; then
                #echo -en "\033[1;31m\nMAC Adress check\t:\tFail \033[0m\n"
                #echo -en "\033[1;31m\n Following interfaces are having different MAC address \033[0m\n"
                echo "<font color=\"red\"><b>Fail</b></font> <font color=\"red\"> (Different MAC Address)<br>"
		echo "`diff -b --ignore-all-space "$PRE_DIR"/hwaddrcompare "$POST_DIR"/hwaddrcompare | grep "<"`" | sed ':a;N;$!ba;s/\n/ /g'
                #echo -en "\033[1;32m\nThe following interfaces are up after the activity \033[0m\n"
                echo "<br>Interfaces up after the activity: <br>"
		diff -b --ignore-all-space "$PRE_DIR"/hwaddrcompare "$POST_DIR"/hwaddrcompare | grep ">" | sed ':a;N;$!ba;s/\n/ /g'
		echo "</font></td>" 
        else
                #echo -en "\nMAC Address check\t:\tPass\n"
		echo "Pass</td>"
        fi
}

cpu()
{
diff -b --ignore-all-space "$PRE_DIR"/cpu "$POST_DIR"/cpu 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nCPUcheck : Pass  (`cat $POST_DIR/cpu`)\n"
echo "<td>Pass (`cat $POST_DIR/cpu`)</td>"
else
#echo -en "\033[1;31m\nCPUcheck : Fail\033[0m\n"
echo "<td><font color=\"blue\"><b>Changed </b></font> <font color=\"blue\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/cpu "$POST_DIR"/cpu`"
echo ")"
echo "</font></td>"
fi
}

memory()
{
diff -b --ignore-all-space "$PRE_DIR"/memory "$POST_DIR"/memory 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nmemorycheck : Pass  (`cat $POST_DIR/memory`G)\n"
echo "<td>Pass (`cat $POST_DIR/memory`G)</td>"
else
#echo -en "\033[1;31m\nmemorycheck : Fail\033[0m\n"
echo "<td><font color=\"blue\"><b>Changed </b></font> <font color=\"blue\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/memory "$POST_DIR"/memory`"
echo ")"
echo "</font></td>"
fi
}

kernel()
{
diff -b --ignore-all-space "$PRE_DIR"/kernelversion "$POST_DIR"/kernelversion 2>&1 > /dev/null
if [ $? = 0 ]
then
#echo -en "\nkernelversioncheck : Pass  (`cat $POST_DIR/kernelversion`)\n"
echo "<td>Pass (`cat $POST_DIR/kernelversion`)</td>"
else
#echo -en "\033[1;31m\nkernelversioncheck : Fail\033[0m\n"
echo "<td><font color=\"blue\"><b>Changed </b></font> <font color=\"blue\"> ("
echo "`diff -by --ignore-all-space "$PRE_DIR"/kernelversion "$POST_DIR"/kernelversion`"
echo ")"
echo "</font></td>"
fi
}
#clear
#printf '\t%100s\n' | tr ' ' -;
#echo -en "\n\t\t\033[35m ########## Pre/Post comparison ############# \033[0m\n"
#printf '\t%100s\n' | tr ' ' -;
echo "<td>`cat /etc/redhat-release |tee -a $OSType`</td>"
kernel
cpu
memory
dfcompare
postfixcompare
sendmailcompare
puppetcompare
selinuxcompare
tzcompare
hostnamecompare
SOEIDIPcompare
HWaddrcompare
}

#---------------------------------------------------------------------------------------------------------------------

#####################################Compare script end########################################################

#---------------------------------------------------------------------------------------------------------------------







###### Function is used to print the useage of script ######
scriptUsage(){
        clear;
        echo
        printf '\t%80s\n' | tr ' ' -
        echo -en "\n\t\t * * * * Host Pre/Post migration check  * * * * \t\n";
        printf '\t%80s\n' | tr ' ' -
        echo -en "\n";
        echo -en "\nThis tool will collect information about host deatils before/after migration"
        echo
        echo -en "\nUsage: $0 -o pre/post/health \n"
        printf '%30s\n' | tr ' ' -
        echo -en "\n\t-o   - Used for option";
        echo -en "\n\thealth - Linux Health Check";
        echo -en "\n\tnetwork - Network Check";
        echo -en "\n\tpre  - Before migration";
        echo -en "\n\tpost - After migration\n";
        printf '%30s\n' | tr ' ' -
}

################ Input validation #########
if [ $# -le 1  ]
then
scriptUsage
echo -en "\nKindly provide \"pre\/post\" keyword and re-execute the script.\n";
exit 1;
else
        #clear;
        option=$1;
        value=$2;
        chq=$3;
        if [ "$option" != "-o" ]
        then
                echo -en "\nPlease check the option \"$option\" provided and re-execute the script.\n";
                exit 1;
        elif [ "$value" == "pre"  ] ||  [ "$value" == "post"  ] || [ "$value" == "health"  ] || [ "$value" == "network"  ] || [ "$value" == "nfs"  ] || [ "$value" == "lastreboot"  ] ||  [ "$value" == "mirroredlv"  ] ||  [ "$value" == "multipath"  ] ||  [ "$value" == "hpphysicaldrive"  ] ||  [ "$value" == "lastpatch"  ] ||  [ "$value" == "noofkernels"  ] ||  [ "$value" == "clusterhealth"  ] ||  [ "$value" == "hbacard"  ] ||  [ "$value" == "ldap"  ] || [ "$value" == "diskusage"  ] || [ "$value" == "timezone"  ] || [ "$value" == "itmrestart"  ] || [ "$value" == "teambondmode"  ] || [ "$value" == "enslno" ]
        then
                #################################################################
                #                       Main Function                           #
                #################################################################
                if [ "$value" == "pre" ]
                then
                	LOGDIR=/home/logs/$chq/before_bounce_scan/`hostname`
                	mkdir -p $LOGDIR
                        #LOGDIR=/home/logs/$chq/before_bounce_scan/`hostname`
                        #mkdir -p $LOGDIR
                        LOG_DIR="/home/logs/$chq-`hostname`/pre/$chq"
                        mkdir -p "$LOG_DIR";
                        OSversion
                        dfcheck
                        Hardware_details
                        Servicescheck
                        selinux
                        timezone
                        hostnamecheck
                        SOEID_IP_Check
			HWADDR_Check
                        OSConfigfielsbackup
                        #chown -R $user /home/logs
                       #echo -en "\nYou can find pre logs under : $LOG_DIR \n";
                        #sleep 2;
                        #echo -en "\nPlease run below commands on segotl0836\n"
                        #echo -en "\n\e[31m scp -pr $user@`hostname -f`:$LOGDIR /tmp/Pre_Logs/  \e[0m \n"
                elif [ "$value" == "health" ]
                then 
                        LinuxHealth
                        dfcheck
                        Hardware_details
                        cpuused
                        memoryused
                        nfsnotresponding
                        selinux
                        readonlyfilesystem
                        multipathcheck
                        hwhealthcheck
                        hostnamecheck
                        SOEID_IP_Check
                        HWADDR_Check
                elif [ "$value" == "network" ]
                then
                        networkcheck

                elif [ "$value" == "nfs" ]
                then
                        nfscheck
                elif [ "$value" == "lastreboot" ]
                then
                        lastrebootcheck
                elif [ "$value" == "mirroredlv" ]
                then
                        mirroredlvcheck
                elif [ "$value" == "multipath" ]
                then
                        multipathcheck1
                elif [ "$value" == "hpphysicaldrive" ]
                then
                        hpphysicaldrivecheck
                elif [ "$value" == "lastpatch" ]
                then
                        lastpatchcheck
                elif [ "$value" == "noofkernels" ]
                then
                        noofkernelscheck
                elif [ "$value" == "clusterhealth" ]
                then
                        clusterhealthcheck
               elif [ "$value" == "hbacard" ]
                then
                        hbacardcheck
               elif [ "$value" == "ldap" ]
                then
                        ldapcheck
               elif [ "$value" == "diskusage" ]
                then
                        diskusagecheck
               elif [ "$value" == "timezone" ]
                then
                        timezcheck
               elif [ "$value" == "itmrestart" ]
                then
                        itmrestartcheck
               elif [ "$value" == "teambondmode" ]
                then
                        teambondmodecheck
               elif [ "$value" == "enslno" ]
                then
			ensrnocheck
              
               else
                        if [ ! -d "/home/logs/$chq-`hostname`/pre/$chq" ]; then
                                echo ""
                                echo "END OF PRE"
                                echo "<td><font color=\"red\"><b>Could not find Before Reboot Results, Can't Continue</b></font></td>"
                                exit 35;
                        fi
                	LOGDIR=/home/logs/$chq/After_bounce_scan/`hostname`
			mkdir -p $LOGDIR
                        LOG_DIR="/home/logs/$chq-`hostname`/post/$chq"
                        mkdir -p "$LOG_DIR";
                        OSversion
                        dfcheck
                        Hardware_details
                        Servicescheck
                        selinux
                        timezone
                        hostnamecheck
                        SOEID_IP_Check
			HWADDR_Check
                        OSConfigfielsbackup
                        #sleep 2;
                        echo "END OF PRE"
                        compare
                       #echo -en "\nYou can find post logs under : $LOG_DIR \n";

                        cleanup
                fi
         fi
fi





