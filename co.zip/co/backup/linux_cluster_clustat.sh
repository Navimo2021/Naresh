#!/bin/ksh
##############################################################################
#
# Script:       linux_cluster_clustat.sh
#
# Description:  ksh script to generate output for ITM monitoring. Checks
#               status from clustat and verify connectivity with fence
#               devices.
#
# Input:        None. Development mode available inside script.
#
# Output:       Status messages for ITM
#
# Revision history
# Rev.  Date        By                          Comment
# ----  ----------  ------------------------    --------------------------------
# 1.0   20xx-xx-xx  Daemon X                    Initial version
# 2.0   2015-06-26  Bo Wiberg                   Major changes. Added checking of
#                                               fence devices and developer mode
#                                               for ease of development.
#                                               Developed on RHEL 6.6
# 3.0   2016-12-14  Lars (M) Bengtsson          RHEL7/Pacemaker cluster support.
#


#
# Initiate variables.
#
status_clustat="0"
status_fence="0"
status_report="0"

#
# DevMode is for status debugging. Enable it by 'DevMode="1"'
#
DevMode="0"
#DevMode="1"

##############################################################################
# Function:     clustat_test
#
# Description:  Uses the clustat command to check the status of the current
#               cluster
#
# Input:        None.
#
#
# Output:       status_clustat: "0" means OK
#                               Anything else is an error.
#
##############################################################################

function clustat_test {

/usr/sbin/clustat 2>&1 | grep -E -q  "disabled|Offline|failed|inactive|CMAN"

if [ $? -eq 0 ]; then
   status_clustat=1
fi

if [ $DevMode = 1 ]; then
  status_clustat=1
fi

}

##############################################################################
# Function:     pcs_resource_test
#
# I: none
# O: status_clustat:  0 is OK, anything else -> error.
##############################################################################

function pcs_resource_test {

# check for dead resources
resource_status=$( /sbin/pcs resource show 2>&1 | egrep -v "Resource Group\:|Started" )
if [ ! -z "${resource_status}" ]; then
        status_clustat=1
fi

# check if pcsd is talking to all nodes
pcsd_offlines=$( /sbin/pcs cluster pcsd-status 2>&1 | grep -i offline )
if [ ! -z "${pcsd_offlines}" ]; then
        status_clustat=1
fi

# check if corosync is talking to all nodes
pcs_corosync_offline=$( /sbin/pcs status nodes corosync | grep Offline | awk '{ print $NF }' )
if [ ${pcs_corosync_offline} != "Offline:" ]; then
        status_clustat=1
fi

# check if cluster is running on this node
cluster_running=$( /sbin/pcs cluster status 2>&1 | grep "cluster is not currently running on this node" )
if [ ! -z "${cluster_running}" ]; then
        status_clustat=1
fi

# check if node in standby mode
pcs_node_standby=$( /sbin/pcs status nodes |head -6 | grep Standby: | awk '{ print $NF }' )
if [ ${pcs_node_standby} != "Standby:" ]; then
        status_clustat=1	
fi

if [ $DevMode = 1 ]; then
        status_clustat=1
fi

}

##############################################################################
# Function:     fence_test
#
# Description:  Function that checks the ability to reach the iLo/iDrac in the
#               cluster
#
# Input:        None.
#
#
# Output:       status_fence:   "0" is OK.
#                               Anything else is an error.
#
##############################################################################

function fence_test {

#
# Read which nodes are in the cluster and check the corresponding fence
# devices for error
#

ccs_tool lsnode | grep -A 10 Node |  tail -n +2 | awk '{ print $1}' \
| while read clusternode ; do
  fence_node -S ${clusternode} > /dev/null 2>&1
  if [ $? -eq 0 ] ; then
    : #echo "OK"
  else
    status_fence=1
  fi
done

if [ $DevMode = 1 ]; then
  status_fence=1
fi

}


##############################################################################
# Function:     pcs_fence_test
#
# Description:  Function that checks the ability to reach the ILO/iDrac in the
#               cluster (RHEL7/Pacemaker version, uses IPMI connected ILO/iDrac)
#

function pcs_fence_test {

fencedevs=$( /sbin/pcs stonith | awk '{print $1}' )
for fencedev in $fencedevs ; do
        if [ $fencedev = "NO" ]; then # if NO is found here, no fence device was configured.
                status_fence=1        # this is also an error on a production cluster->raise error.
                break
        fi
        fenceattrs=$( /sbin/pcs stonith show ${fencedev} | grep Attributes: )
        for attr in $fenceattrs ; do
                setting=$( echo $attr | cut -d = -f 1 )
                value=$( echo $attr | cut -d = -f 2 )
                if [ $setting = login ]; then
                        login=$value
                elif [ $setting = passwd ]; then
                        passwd=$value
                elif [ $setting = ipaddr ]; then
                        ipaddr=$value
                fi
        done
        # echo $ipaddr $login $passwd
        # got info; try ipmitool login
        stat=$( ipmitool -I lanplus -H $ipaddr -A PASSWORD -U $login -P $passwd power status 2>&1 )
        RC=$?
        if [ $RC != 0 ]; then # Oops, login failed. Flag for later.
                status_fence=1
        fi
done

# check if fencing stopped status
fence_stop=$( /sbin/pcs stonith  2>&1 |egrep -v Started )
if [ ! -z "${fence_stop}" ]; then
        status_fence=1	
fi

}



##############################################################################
# Function:     report_status
#
# Description:  Compile the error messsages from function "fence_test" and
#               "clustat_test"
#
# Input:        The variables "status_fence" and "status_clustat"
#
#
# Output:       Message to the monitoring software
#
##############################################################################

function report_status {

if [ -x /sbin/pcs ]; then
        # Pacemaker cluster
        pcs_fence_test
        pcs_resource_test
else
        # CMAN/rgmanager cluster
        fence_test
        clustat_test
fi

if [ $status_fence -ne 0 -a $status_clustat -ne 0 ]; then
   echo "O|C|Problem with fence device and cluster state|Not Ok"
elif [ $status_fence -ne 0 -a $status_clustat -eq 0 ]; then
   echo "O|C|Problem with fence device|Not ok"
elif [ $status_fence -eq 0 -a $status_clustat -ne 0 ]; then
   echo "O|C|Service or Node down|Not ok"
else
   echo "O|I|ALL OK|OK"
fi

}

##############################################################################
# Function:     devmode
#
# Description:  Display a small warning banner on std error if enabled.
#
# Input:        DevMode variable.
#
#
# Output:       Message on std error if run in DevMode.
#
##############################################################################

function devmode {

if [ "${DevMode}" = "1" ]; then
  echo " "                                              >&2
  echo " !!! Please observe that Dev mode is on"        >&2
  echo " !!! Results is not reliable "                  >&2
  echo " "                                              >&2
fi

}

##############################################################################
#
#               MAIN
#
##############################################################################

#devmode
report_status
