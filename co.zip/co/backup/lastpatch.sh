echo  "${BOLD}LAST PATCH${RESET}"
echo -e "=========== \n"

RHEL_VERSION=`facter lsbmajdistrelease`
if [[ $RHEL_VERSION = 7 ]]; then
 PATCH_DATE_RHEL7=`rpm -qa --last | egrep -w kernel-3* | head -1 | awk  '{print $2,$3,$4,$5,$6,$7}'`
 echo -e "$PATCH_DATE_RHEL7 \n"
elif [[ $RHEL_VERSION = 6 ]]; then
 PATCH_DATE_RHEL6=`rpm -qa --last | egrep -w kernel-2* | head -1 | awk  '{print $2,$3,$4,$5,$6,$7}'`
 echo -e "$PATCH_DATE_RHEL6 \n"
fi

