#!/bin/bash
echo "Enter the mount point name"
read MOUNTPOINT
lsblk  |grep "$MOUNTPOINT" |awk '{print $1}'| cut --complement -c 1-2 |cut -d "-" -f 2 > /tmp/lvname
SEGTYPE=$(for i in `cat /tmp/lvname`; do lvs --segments |grep $i |awk '{print $5}'; done)
sleep 5
lsblk  |grep "$MOUNTPOINT" |awk '{print $1}'| cut --complement -c 1-2 |cut -d "-" -f 1 > /tmp/vgname
vgname=$(cat /tmp/vgname)
echo "The File system $MOUNTPOINT is $SEGTYPE"
FSTYPE=$(df -ThP $MOUNTPOINT |awk '{print $2}' |tail -1)
echo "The File system type of $MOUNTPOINT is $FSTYPE"
if egrep -q '6|7' /etc/redhat-release;
then
if grep -q $vgname /var/lib/puppet/state/resources.txt;
then
echo "File system $MOUNTPOINT is managed by puppet. Please make a requried changes in hiera server"
else
echo "File system $MOUNTPOINT is NOT managed by puppet."
fi
fi
if grep -q 8 /etc/redhat-release;
then
if grep -q $vgname /opt/puppetlabs/puppet/cache/state/resources.txt;
then
echo "File system $MOUNTPOINT is managed by puppet. Please make a requried changes in hiera server"
else
echo "File system $MOUNTPOINT is NOT managed by puppet."
fi
fi

