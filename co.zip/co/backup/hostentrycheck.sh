#!/bin/bash

export ip=10.196.200.18
export fqdn=techlqa5273.eu.techem.corp
export shortname=techlqa5273

#grep -w ""$ip   $shortname    $fqdn"" /etc/hosts
cat /etc/hosts | egrep -w "$ip|$fqdn|$shortname"
