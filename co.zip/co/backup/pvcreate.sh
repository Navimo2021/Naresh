#!/bin/bash

###########################################################################
#                                                                         #
# Created by Dineshkumar Kadirvelan (kadirveland@hcl.com) on 13-01-2020   #
#                                                                         #
###########################################################################


#Define colours

RED=`tput setaf 1`
RESET=`tput sgr0`
BOLD=`tput bold`
GREEN=`tput setaf 2`
EXIT_STATUS=0

if ! [ $# -gt 0 ]; then
   echo echo "USAGE: $0 [-h] [--help] [-d] [--disk diskname] [-v][--volumegroup vgname]  [-l] [--lvname] [size] [-p] [--path]"
   exit 1
else
while [ $# -gt 0 ]
do
  case "$1" in
        -h|--help )
              echo "USAGE: $0 [-h] [--help] [-d] [--disk diskname] [-v][--volumegroup vgname] [-l] [--lvname] [size] [-p] [--path]"
              shift
              exit 2
              ;;
         -d|--disk )
              DISKS=$2
              echo "$DISKS" > /tmp/disks
              cat /tmp/disks | sed 's/,/ /g' | fmt -1 > /tmp/diskin
              DISK=/tmp/diskin
              cat $DISK |
              while read line 
              do
              lvmdiskscan | grep -w "$line" | awk -F " " '{print $1}' > /tmp/disk
              if ! [ -s /tmp/disk ]; then
                   echo "${RED}Disk $line not found{RESET}"
                   exit 3
              else
               echo -e "${GREEN}Disk $line found${RESET}. Creating PV.. \n"
               pvcreate ${line}
               echo -e "\n"
               
              fi
              done
              shift
              shift
              ;;
         -v|--volumegroup )
               VG=$2
               vgs | grep -w "$2" | awk -F " " '{print $1}' > /tmp/vg
               if  [ -s /tmp/vg ]; then
                    echo -e "Volume group exist \n"
                    EXIT_STATUS=4
                    break
               else
                  cat /tmp/disks | sed 's/,/ /g'  > /tmp/disk_vg
                  VG_DISK=`cat /tmp/disk_vg`
                   vgcreate $VG $VG_DISK
                   echo -e "\n"
               fi
               vgs | grep -w "$2" | awk -F " " '{print $1}' > /tmp/vg
               shift
               shift
               ;;
          -l|--lvname )
             LV_NAME=$2
             SIZE=$3
             VG=`cat /tmp/vg`
             lvcreate -L $SIZE -n ${LV_NAME} $VG
             lvs  $VG | grep ${LV_NAME}
             if [ "$?" != "0" ]; then
                echo "Logical Volume not Created"
                exit 5
             fi
             mkfs.xfs /dev/mapper/${VG}-${LV_NAME}
             lvs  $VG | grep ${LV_NAME} | awk -F " " '{print $1}' > /tmp/lv
             shift
             shift
             shift
             ;;
           -p|--mountpath )
             MOUNT_PATH=$2
             VG=`cat /tmp/vg`
             LV=`cat /tmp/lv`
             df -h | grep ${MOUNT_PATH}
             if [[ $? == 0 ]]; then
                echo "File system already exist, exiting"
                exit 6
             else
             mkdir -p ${MOUNT_PATH}
             echo "/dev/mapper/$VG-$LV  ${MOUNT_PATH}  xfs     defaults    0   0" >> /etc/fstab
             mount ${MOUNT_PATH}
             echo -e "\n"
             if [[ $? = 0 ]]; then
                echo "${GREEN}Filesystem ${MOUNT_PATH} mounted  successfully${RESET}"
                echo -e "\n"
                echo "Fstab entries Added. Please alter the mount options in fstab if required"

             else
                echo "${RED}Oops Something wrong please check further${RESET}"
             fi
             fi
             shift
             shift
             exit
             ;;


            * )
             echo "USAGE: $0 [-h] [--help] [-d] [--disk diskname] [-v][--volumegroup vgname] [-l] [--lvname] [size] [-p] [--path]"
             shift
             exit 1
             ;;
   esac
done
fi
if  ! [[ $EXIT_STATUS -eq 0 ]]; then
    echo -n "Do you  want to proceed with LV creation Y/N: "
    read Answer
CHECK=0
while [ $CHECK -eq 0 ]
do
case "$Answer" in
 Y|y )
  echo -e "\n"
  echo -e "Proceeding with LV creation \n"
  LV_NAME=$4
  SIZE=$5
  MOUNT_PATH=$7
  VG=`cat /tmp/vg`
  df -h | grep ${MOUNT_PATH}
  if [[ $? == 0 ]]; then
     echo "${RED}File system already exist, exiting${RESET}"
     exit 6
  else
    lvcreate -L $SIZE -n $LV_NAME $VG
    lvs  $VG | grep $LV_NAME
    if [ "$?" != "0" ]; then
    echo "Logical Volume not Created"
    exit 4
    fi
    mkfs.xfs /dev/mapper/${VG}-${LV_NAME}
    lvs  $VG | grep $LV_NAME | awk -F " " '{print $1}' > /tmp/lv
    LV=`cat /tmp/lv`
    echo "/dev/mapper/$VG-$LV  ${MOUNT_PATH}  xfs     defaults    0   0" >> /etc/fstab
    mkdir -p ${MOUNT_PATH}
    mount ${MOUNT_PATH}
    echo -e "\n"
    if [[ $? = 0 ]]; then
      echo "${GREEN}Filesystem ${MOUNT_PATH} mounted  successfully${RESET}"
    else
      echo "${RED}Oops Something wrong please check further${RESET}"
    fi
    fi
    CHECK=1
    shift
    shift
    shift
    shift
    shift
    shift
    ;;
  N|n )
   echo "Exiting....done"
   CHECK=2
   ;;
 esac
done
fi

