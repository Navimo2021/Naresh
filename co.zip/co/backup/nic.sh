#Check the NIC status

echo "${BOLD}NIC SPEED AND STATUS${RESET}"
echo -e "==================== \n"
facter interfaces > /tmp/nics
cat /tmp/nics | sed 's/,/ /g' | fmt -1 | grep -v lo > /tmp/device
      NIC=`cat /tmp/device | sed 's/_/:/g'`
      for i in $NIC
      do
        echo  "DEVICE: $i"
        ethtool $i | egrep -w 'Speed'
        NIC_STATUS=`ethtool $i| egrep -w "Link detected" | awk -F ":" '{print $2}'| awk -F " " '{print $1}'`
          if  [[ $NIC_STATUS = yes ]];then
            echo "        LINK Status:${GREEN}UP$RESET"
          elif [[ $NIC_STATUS = no ]];then
           echo -e "        LINK Status:${RED}DOWN$RESET\n"
          fi
        done

