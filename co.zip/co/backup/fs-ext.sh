#!/bin/bash
echo "Enter the mount point name"
read MOUNTPOINT
lsblk  |grep "$MOUNTPOINT" |awk '{print $1}'| cut --complement -c 1-2 |cut -d "-" -f 2 > /tmp/lvname
SEGTYPE=$(for i in `cat /tmp/vgname`; do lvs --segments |grep $i |awk '{print $5}'; done)
lsblk  |grep "$MOUNTPOINT" |awk '{print $1}'| cut --complement -c 1-2 |cut -d "-" -f 1 > /tmp/vgname
vgname=$(cat /tmp/vgname)
echo "The File system $MOUNTPOINT is $SEGTYPE"
FSTYPE=$(df -ThP $MOUNTPOINT |awk '{print $2}' |tail -1)
echo "The File system type of $MOUNTPOINT is $FSTYPE"
RHEL=$(egrep '6|7|8' /etc/redhat-release)
if [ $RHEL != 8 ];
then  
if grep -q $vgname /var/lib/puppet/state/resources.txt;
then
echo "File system $MOUNTPOINT is managed by puppet. Please make a requried changes in hiera server"
fi
fi
if [ $RHEL = 8 ];
then
if grep -q $vgname /opt/puppetlabs/puppet/cache/state/resources.txt;
then
echo "File system $MOUNTPOINT is managed by puppet. Please make a requried changes in hiera server"
fi
fi
