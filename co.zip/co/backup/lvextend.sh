#!/bin/bash

###########################################################################
#                                                                         #
# Created by Dineshkumar Kadirvelan (kadirveland@hcl.com) on 13-01-2020   #
#                                                                         #
###########################################################################


#Define colours

RED=`tput setaf 1`
RESET=`tput sgr0`
BOLD=`tput bold`
GREEN=`tput setaf 2`
if ! [ $# -gt 0 ]; then
     echo "${BOLD}USAGE: $0 [-h|--help] [-d|--disk diskname] [-v|--volumegroup vgname] [-l|--lvname vgname size]${RESET} "
     exit 1
else

while [ $# -gt 0 ]
do
  case "$1" in
        -h|--help )
              echo "${BOLD}USAGE: $0 [-h|--help] [-d|--disk diskname] [-v|--volumegroup vgname] [-l|--lvname vgname size]${RESET}"
              shift
              exit 1
              ;;
         -d|--disk )
              DISKS=$2
              echo "$DISKS" > /tmp/disks
              cat /tmp/disks | sed 's/,/ /g' | fmt -1 > /tmp/diskin
              DISK=/tmp/diskin
              cat $DISK |
              while read line
              do
              lvmdiskscan | grep -w "$line" | awk -F " " '{print $1}' > /tmp/disk
              if ! [ -s /tmp/disk ]; then
                   echo "${RED}Disk $line not found{RESET}"
                   exit 3
              else
               echo -e "Disk ${GREEN}$line${RESET} found. Creating PV.. \n"
               pvcreate ${line}

              fi
              done
              shift
              shift
              ;;

           -v|--volumegroup ) 
              VG=$2
              cat /tmp/disks | sed 's/,/ /g'  > /tmp/disk_vgex 2> /dev/null
              VG_EXT=`cat /tmp/disk_vgex`
              vgs | grep -w "$2" | awk -F " " '{print $1}' > /tmp/vg
               if ! [ -s /tmp/vg ]; then
                 echo "${RED}Volume group does not exist${RESET}"
                 exit 4
               else
                 echo -e "${GREEN}Volume group $VG exist${RESET} \n"
                 vgextend $VG ${VG_EXT} 2> /tmp/vglog | grep -v vgextend
                 echo -e "\n"
               fi
               vgs | grep -w "$2" | awk -F " " '{print $1}' > /tmp/vg
               shift
               shift
               ;;
           -l | --lvname )
              
             LV=$2
             VG=`cat /tmp/vg`
             SIZE=$3
             LV_CHECK=`lvs | grep -w "$LV"`
             if [ -z "${LV_CHECK}" ]; then 
                echo -e "${RED}Logical Volume $LV does not exist${RESET} \n"
             else
              
             #Semaphore Check

             SEMAPHORE_TOTAL=`ipcs -sl | grep -w "max number of arrays" | awk -F "=" '{print $2}' | awk -F " " '{print $1}'`
             SEMAPHORE_USED=`ipcs -su | grep -w "used arrays" | awk -F "=" '{print $2}' | awk -F " " '{print $1}'`
             if [[ $SEMAPHORE_USED -eq $SEMAPHORE_TOTAL ]]; then
             echo "${RED}Semaphore Array limit Reached. Please increase the semaphore value and then extend the Filesystem${RESET}"
             exit 1
             fi
             
             #Check the Type of lv
             LV_TYPE=`lvdisplay -m $VG | grep -i Type | awk -F " " '{print $2}' | uniq` 
             if [[ $LV_TYPE = mirror ]]; then  
                echo "${RED}LVM is mirrored, Please break the mirror and do the extension manually${RESET}."
             elif [[ $LV_TYPE = striped ]]; then
                echo "${RED}LVM is striped, Please check and do the extension manually${RESET}."
             elif [[ $LV_TYPE = linear ]]; then
                echo -e "LVM is Linear. Extending Logical Volume... \n"
                lvextend -L +"$SIZE" /dev/${VG}/${LV}
                if ! [[ $? -eq 0 ]]; then
                echo -e "\n"
                echo -e "${RED}LogicalVolume ${LV} not extended, Please check further and do the extension${RESET} \n"
                exit
                else 
                xfs_growfs /dev/${VG}/${LV}
                echo -e "\n"
                if [[ $? -eq 0 ]]; then
                   echo -e "${GREEN}Logical Volume $LV Extended Successfully${RESET} \n"
                else
                  echo -e "${RED}Oops Something went wrong. Please Check further${RESET} \n"
                fi
                fi
             fi 
             fi
             shift
             shift
             shift
             exit
             ;;
                
           * )
             echo "${BOLD}USAGE: $0 [-h|--help] [-d|--disk diskname] [-v|--volumegroup vgname] [-l|--lvname vgname size]$RESET"
             shift
             exit 1
             ;;

   esac   
done
fi
