OS_VERSION=`facter lsbmajdistrelease`
if [[ $OS_VERSION = 7 ]]; then
 echo "${BOLD}NTP CHECK${RESET}"
 echo -e "=========== \n"
 chronyc sources
 echo -e "\n"
 echo "M/S column indicates the mode of the source".
 echo " ^ means a server, = means a peer and # indicates a locally connected reference clock."
 echo "* indicates the source to which chronyd is current synchronised. + indicates other acceptable sources."
 echo "? indicates sources to which connectivity has been lost.x indicates a clock which chronyd thinks is is a falseticker."
 echo -e "~ indicates a source whose time appears to have too much variability. \n"
 chronyc tracking
 echo -e "\n"

else
 echo "NTP CHECK"
 echo -e "========== \n"
 ntpq -pn
 echo -e "\n"
 echo "* indicates the source to which chronyd is current synchronised. + indicates other acceptable sources."
 echo "? indicates sources to which connectivity has been lost.x indicates a clock which chronyd thinks is is a falseticker."
 echo -e "~ indicates a source whose time appears to have too much variability. \n"
fi

NTP_SYNC=`ntpstat | grep -w synchronised | awk -F " " '{ print $1}'`
if ! [[ NTP_SYNC = synchronised ]]; then
  echo  "NTP is ${GREEN}synchronised${RESET}"
else
  echo "NTP is ${RED}not synchronised${RESET}"
fi
