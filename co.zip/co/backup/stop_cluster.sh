#!/bin/bash
clustat
service rgmanager stop
service clvmd stop
sleep 3
service cmirror stop
fence_tool leave
cman_tool leave remove
service cman stop
