#!/bin/bash 
recipients="naresh.deenadayalan@hcl.com nagaraj_a@hcl.com"
sshpass -p Nov@2021 ssh -n -o StrictHostKeyChecking=no -l a330505 segotl3123 uptime
if [ $? != 0 ]
then
echo "Kindly take an action. server segotl3123 is not reahcable." | mail -s "segotl3123 uptime status" $recipients
fi
