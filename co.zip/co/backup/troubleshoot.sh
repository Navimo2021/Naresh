#!/bin/bash
RED=`tput setaf 1`
RESET=`tput sgr0`
GREEN=`tput setaf 2`
BLUE=`tput setaf 4`
BOLD=`tput bold`
#Check User is root

USER=`whoami`

if ! [[ $USER = root ]]; then
echo "Run $0 as root user"
exit 1
else
#Collect System Information

echo -e "################################################################## \n"

echo -e "       ${BOLD}SYSTEM INFORMATION${RESET}    \n"
HOST=`facter fqdn`
VENDOR=`facter manufacturer`
CPU_MODEL=`facter processor0`
IP=`facter ipaddress`
MAC=`facter macaddress`
VERSION=`facter lsbdistdescription`
KERNEL=`facter kernelrelease`
CPU=`lscpu | grep -w "^CPU(s)" | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
MEMORY=`facter memorysize`
SWAP=`facter swapsize`
SELINUX=`facter selinux_current_mode`
echo "${BLUE}HOSTNAME${RESET}:$HOST"
echo "${BLUE}VENDOR${RESET}:$VENDOR"
echo "${BLUE}CPU_MODEL${RESET}:$CPU_MODEL"
echo "${BLUE}OS${RESET}:$VERSION"
echo "${BLUE}KERNEL${RESET}:$KERNEL"
echo "${BLUE}PUBLIC IP${RESET}:$IP"
echo "${BLUE}MAC${RESET}:$MAC"
echo "${BLUE}CPU COUNT${RESET}:$CPU"
echo "${BLUE}MEMORY${RESET}:$MEMORY"
echo "${BLUE}SWAP${RESET}:$SWAP"
echo -e "${BLUE}SELINUX MODE${RESET}:$SELINUX \n"

echo -e "################################################################## \n"

#check uptime of the server

echo  "${BOLD}UPTIME DETAILS${RESET}"
echo -e "============== \n"
UP=`facter system_uptime`
echo -e  "$UP \n"

#Check the NIC status

echo "${BOLD}NIC SPEED AND STATUS${RESET}"
echo -e "==================== \n"
INTERFACES=`facter interfaces > /tmp/interfaces`
NIC=`cat /tmp/interfaces | sed 's/,/ /g' | fmt -1 | grep -v lo`
for i in $NIC
do
echo  "DEVICE: $i"
ethtool $i | egrep -w 'Speed'
NIC_STATUS=`ethtool $i| egrep -w "Link detected" | awk -F ":" '{print $2}'| awk -F " " '{print $1}'`
 if  [[ $NIC_STATUS = yes ]];then
          echo "        LINK Status:${GREEN}UP$RESET"
    elif [[ $NIC_STATUS = no ]];then
           echo -e "        LINK Status:${RED}DOWN$RESET\n"
 fi
done
echo -e "\n"

# Check the status of the Gateway

echo "${BOLD}GATEWAY CHECK${RESET}"
echo -e "============= \n"
VAR=`ip r | grep  ^default | awk -F " " '{print $3}'`
#IP address REGEX
REGEX="[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"

#REGEX CHECK
if  [[ $VAR =~ $REGEX ]]; then
IP=${BASH_REMATCH[0]}
ping -c4 $IP > /dev/null
if [ $? -eq 0 ]; then
   echo -e "Gateway $VAR is ${GREEN} Reachable ${RESET} \n"
 else
   echo "Gateway $VAR is ${RED} not reachable ${RESET} \n"
fi
fi

#check DNS resolution

echo  "${BOLD}DNS CHECK${RESET}"
echo -e "========= \n"
nslookup ${HOST}
 if [ $? -eq 0 ]; then
   echo -e "DNS Resolution is ${GREEN} SUCCESS ${RESET} \n"
   else
   echo -e "DNS Resolution ${RED} Failed ${RESET} \n"
 fi


# check Memory swap and cpu utilisation

echo "${BOLD}MEMORY SWAP AND CPU UTILIZATION${RESET}"
echo -e "=============================== \n"
MEM_TOTAL=`cat /proc/meminfo | grep -i MemTotal | awk -F " " '{print $2}'`
MEM_FREE=`cat /proc/meminfo | grep -i MemFree | awk -F " " '{print $2}'`
MEM_USED=`cat /proc/meminfo | grep -i MemAvailable | awk -F " " '{print $2}'`
echo -e "Total Memory=$(expr $MEM_TOTAL / 1024)MB" "Used=$(expr $MEM_USED / 1024)MB" "Free=$(expr $MEM_FREE / 1024)MB \n"
SWAP_TOTAL=`cat /proc/meminfo | grep -i SwapTotal | awk -F " " '{print $2}'`
SWAP_FREE=`cat /proc/meminfo | grep -i SwapFree | awk -F " " '{print $2}'`
SWAP_USED=$(expr $SWAP_TOTAL - $SWAP_FREE)
echo -e "Total SWAP=$(expr $SWAP_TOTAL / 1024)MB" "Used=$(expr $SWAP_USED / 1024)MB" "Free=$(expr $SWAP_FREE / 1024)MB \n"
CPU_USER=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $2}'`
CPU_SYSTEM=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $5}'`
CPU_IDLE=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $8}'`
CPU_WAIT=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $11}'`
CPU_STEAL=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $14}'`
echo -e "CPU user utilisation=$CPU_USER% CPU system utilisation=$CPU_SYSTEM% CPU free=$CPU_IDLE% \n"
echo -e "IOWAIT=$CPU_WAIT% CPU STEAL=$CPU_STEAL% \n"
echo "${RED}NOTE${RESET}: More IO Wait and CPU steal will cause performance issues"
echo -e "!!!!Please investigate further if you see more IO wait and CPU steal on server!!!! \n"

# Load Average
echo  "${BOLD}LOAD AVERAGE OF LAST 15 MINUTES${RESET}"
echo -e "=============================== \n"
LOAD=`cat /proc/loadavg | awk -F " " '{print $3}'`
echo -e "$LOAD \n"

#LOAD CHECK
LOAD1=`cat /proc/loadavg | awk -F " " '{print $3}'| awk -F "." '{print $1}'`
if [[ $LOAD1 -gt $CPU ]]; then
 echo -e "${RED}LOAD IS HIGHER${RESET} than amount of CPU cores we have on the server.\n"
else
 echo -e "Load is ${GREEN} normal ${RESET} \n"
fi

#Display Top process consuming more CPU

CPU_PROCESS=`ps -eo pcpu,pid,user,args | head -1 ; ps -eo pcpu,pid,user,args | sort -nk 1 -r | head -10`

echo -e "${BOLD}TOP 10 CPU CONSUMING PROCESS${RESET}"
echo "============================"
echo -e "$CPU_PROCESS \n"

#Check active ( running ) and queued processes
echo  "${BOLD}Active ( running ) and queued (blocked D-state) processes${RESET}"
echo  "========================================================="
VMSTAT=`vmstat 1 10 > /tmp/vmstat.txt`
sleep 5
RUNQUEUE_COUNT=`cat /tmp/vmstat.txt | awk 'BEGIN{FS= " "} {print $1 " "  $2}'  | grep -v ^procs | awk 'END{print $1}'`
BLOCKED_COUNT=`cat /tmp/vmstat.txt | awk 'BEGIN{FS= " "} {print $1 " "  $2}'  | grep -v ^procs | awk 'END{print $2}'`
echo -e "PROCESSES in RunQueue = $RUNQUEUE_COUNT  BLOCKED Process = $BLOCKED_COUNT\n"
 if [[ $RUNQUEUE_COUNT -gt $CPU ]]; then
   echo "${RED}NOTE${RESET}:If Run queue value is above installed CPU cores continuously, Please investigate further."
   echo "    If Load average is high and no processes are being actively running and if you see more  Blocked process (D State)"
   echo -e "    then its time to review Storage performance or verification of any OS component like NFS/NIC/HBA etc \n"
 fi
QUEUE_PROCESS=`ps -eo stat,pid,user,command | egrep "^STAT|^D|^R"`
echo -e "$QUEUE_PROCESS \n"

#Display Top processes consuming memory

MEMORY_PROCESS=`ps aux  | awk '{print $6/1024 " MB\t\t" $11}'  | sort -nr | head -10`
echo -e "${BOLD}TOP 10 MEMORY CONSUMING PROCESS${RESET}"
echo "==============================="
echo -e "$MEMORY_PROCESS \n"

fi

