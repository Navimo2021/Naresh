cat /tmp/nics | sed 's/,/ /g' | fmt -1 | grep -v lo > /tmp/device
FILE=/tmp/device
cat $FILE |
while read line
do
 echo  "DEVICE: $line"
 IP=`facter ipaddress_$line`
 SUBNET_MASK=`facter netmask_$line`
 MAC_ADDRESS=`facter macaddress_$line`
 echo "IP=$IP SubnetMask=$SUBNET_MASK MacAddress=$MAC_ADDRESS"
done

