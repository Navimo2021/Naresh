#Check for readonly FS
READONLY_FS=`cat /proc/mounts | grep ro, | grep -v "tmpfs"`
if [[ ! -z ${READONLY_FS} ]]; then
 echo "Readonly Filesystem Found"
 echo "${READONLY_FS}"
else
 echo "No Readonly Filesystem on Server"
fi

