#! /bin/bash
#set -x
# Script to kick-off a tcpdump that will restart every TOUT minutes.
# Will trace all NFS-hosts having filesystem name containing 'stg|arch', otherwise defaults '127.0.0.1"
# Feed it to 'at' from cmdline as:   echo "/path/to/file/tcpdump.sh" | at now   , to disown it completely.
# Christian / a221681
# 2016-10-11

TOUT=2			# Timeout. (1440 minutes is 24 hours)
INTERFACE=eth2		# Linux network interface name.
OUTPATH=/tmp		# Directory or mountpoint to store output files.
NROFFILES=50		# Number of files to create before rotating.
FILESIZE=500		# Size of output files.

# Don't edit beond this point

OUTFILES=${OUTPATH}/${INTERFACE}.$(hostname).pcap
HOSTS=$(mount | grep nfs | egrep -e 'stg|arch' | cut -d= -f5 | cut -d \) -f1 | xargs echo | sed 's/ / or /g')

while [ 1 ];do
  timeout --signal=SIGINT ${TOUT}m tcpdump -pni $INTERFACE -s 0 -W $NROFFILES -C $FILESIZE -w $OUTFILES host ${HOSTS:-127.0.0.1}
done
