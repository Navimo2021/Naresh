#!/bin/bash
rm -rf output.txt
rm -rf result.txt
rm -rf fail.txt
rm -rf failtmp.txt
rm -rf raw_output*

SERVERS=$1
USERNAME=$2
PASSWORD=$3
CHOICE=$4
CRNO=$5
COMMANDEXEC=$6
TIMEOUT=15

if [ "$COMMANDEXEC" = "" ]; then
	COMMANDEXEC=$CRNO
fi

CHECKSCRIPT="/unixadmins/WebScripts/.checks/check_test.sh"

uptimecheck()
{
	sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                uptime " > result.txt 2> failtmp.txt
        CODE=$?
	if grep -q "Could not resolve hostname" failtmp.txt; then
		printf "<td align=\"center\"><font color=\"red\"><b>Could not resolve Hostname</b></font></td>" >> output.txt
        elif [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif ! grep days result.txt>/dev/null; then
		printf "<td align=\"center\"><font color=\"red\">$(cat result.txt)</font></td>" >> output.txt
	else
                #printf "<td>$i</td>" >> output.txt
		
                printf "<td>$(cat result.txt)</td>" >> output.txt
        fi
	cat failtmp.txt >> fail.txt
}

readonlycheck()
{
	sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                cat /proc/mounts | grep ro,
		cat /dev/null " > result.txt 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
		#printf "<td>$i</td>" >> output.txt
		printf "<td align=\"center\">No Read-only File System Found</td>" >> output.txt
	else
                #printf "<td><font color=\"red\">$i</font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\">$(cat result.txt)</font></td>" >> output.txt
        fi
}

clustercheck()
{
	sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /usr/sbin/clustat
                cat /dev/null " > result.txt 2> fail.txt
        CODE=$?
	if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
	elif grep -q "not found" fail.txt; then
		#printf "<td>$i</td>" >> output.txt
		printf "<td align=\"center\">Server is not Clustered</td>" >> output.txt
	elif grep -q "Permission denied" fail.txt; then
		#printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
		printf "<td align=\"center\"><font color=\"red\"><b>Permission Denied</b></font></td>" >> output.txt	
	else
		#printf "<td><font color=\"red\">$i</font></td>" >> output.txt
		printf "<td align=\"center\"><font color=\"red\">Server is Clustered</font></td>" >> output.txt
	fi
}

tsmversioncheck()
{
	sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
 		rpm -qa | grep -i tdp              
		echo \"<br>\"
		rpm -qa | grep TIVsm-BA | awk -F '-' {'print $3'} | cut -d '.' -f1,2,3,4 " > result.txt 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        else
                #printf "<td>$i</td>" >> output.txt
                printf "<td>$(cat result.txt)</td>" >> output.txt
        fi
	
}

osversioncheck()
{
        sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                cat /etc/*release " > result.txt 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        else
                #printf "<td>$i</td>" >> output.txt
                printf "<td>$(cat result.txt)</td>" >> output.txt
        fi
}

kernelversioncheck()
{
        sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                uname -r " > result.txt 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        else
                #printf "<td>$i</td>" >> output.txt
                printf "<td>$(cat result.txt)</td>" >> output.txt
        fi
}
physicalvirtualcheck()
{
	sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /usr/sbin/dmidecode -t 1  | grep \"Manufacturer:\" 
		cat /dev/null " > result.txt 2>> fail.txt
	CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
	elif [ ! -s result.txt ]; then
		printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
	elif ! grep -q "VMware" result.txt; then
		printf "<td align=\"center\"><font color=\"blue\">$(cat result.txt)</font></td>" >> output.txt	
        else
                #printf "<td>$i</td>" >> output.txt
                printf "<td>$(cat result.txt)</td>" >> output.txt
        fi

}
commandcheck()
{
        sshpass -p $PASSWORD timeout $TIMEOUT ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
		 echo '$PASSWORD' | sudo -S $COMMANDEXEC
                cat /dev/null " > result.txt 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
		printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
	else
                printf "<td>$(cat result.txt)</td>" >> output.txt
        fi
}

linuxhealthcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o health
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi
sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
        echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


ldapcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o ldap
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi
sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
        echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

networkcheck()
{
        sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o network
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

nfscheck()
{

sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o nfs
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"

}

lastrebootcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o lastreboot
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


lastpatchcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o lastpatch
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


noofkernelscheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o noofkernels
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


clusterhealthcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o clusterhealth
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


mirroredlvcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o mirroredlv
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

multipathcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o multipath
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


diskusagecheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o diskusage
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


timezonecheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o timezone
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

itmrestart()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o itmrestart
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

teambondmodecheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o teambondmode
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

enslnocheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o enslno
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

hbacardcheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o hbacard
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}


hpphysicaldrivecheck()
{
sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o hpphysicaldrive
                 cat /dev/null " > result.txt 2>> failtmp.txt
        CODE=$?
        if [ $CODE -ne 0 ]; then
                #printf "<td><font color=\"red\"><b>$i</b></font></td>" >> output.txt
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
        elif [ ! -s result.txt ]; then
                printf "<td align=\"center\"><font color=\"red\">No Information Found</font></td>" >> output.txt
        else
                printf "$(cat result.txt)" >> output.txt
        fi

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
              echo '$PASSWORD' | sudo -S /bin/rm /tmp/check_test.sh"
}

beforerebootcheck()
{
	sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ 2>> fail.txt
	CODE=$?
        if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to access the Server</b></font></td>" >> output.txt
                return;
        fi

	# Backups to Save - /home/a227367/WebScripts/Reboot_Backups/${CRNO}_${i}.txt
	sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
		#echo '$PASSWORD' | sudo -S /tmp/check.sh.x -o pre $CRNO
		echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o pre $CRNO
		echo '$PASSWORD' | sudo -S chown -R $USERNAME /home/logs
		cat /dev/null " > result.txt 2> failtmp.txt
	CODE=$?
        if [ $CODE -ne 0 ]; then
		printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server </b></font></td>" >> output.txt
		return;
	else
		sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -pr ${USERNAME}@${i}:/home/logs/${CRNO}/before_bounce_scan/* /tmp/Pre_Logs/ 2>> fail.txt
		#CODE=$?
	        #if [ $CODE -ne 0 ]; then
        	#        printf "<td align=\"center\"><font color=\"red\"><b>Failed to Copy-back Data to Jump-Host Server</b></font></td>" >> result.txt
                #	return;
        	#fi
		[ -s result.txt ] || echo "<td><font color=\"red\"><b>Could not Fetch any Results, Please check OS</b></font></td>" >> result.txt
		#result=$(cat result.txt)
		#OLDIFS=$IFS
		#IFS=$'\n'
		#for line in $result
		#do
		#	printf "<td>$line</td>" >> output.txt
		#done
		#IFS=$OLDIFS
		printf "$(cat result.txt)" >> output.txt
	fi
	
	cat failtmp.txt >> fail.txt
	rawoutputformat
}

afterrebootcheck()
{
	sshpass -p $PASSWORD scp -o StrictHostKeyChecking=no -p $CHECKSCRIPT $USERNAME@$i:/tmp/ > /dev/null 2>> fail.txt

        sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ConnectionAttempts=1 -l $USERNAME $i "
                #echo '$PASSWORD' | sudo -S /tmp/check.sh.x -o post $CRNO
                echo '$PASSWORD' | sudo -S /bin/bash /tmp/check_test.sh -o post $CRNO
		#rm -rf /tmp/check.sh.x
                rm -rf /tmp/check_test.sh
		cat /dev/null " > result.txt 2> failtmp.txt
        CODE=$?
	if [ $CODE -ne 0 ]; then
                printf "<td align=\"center\"><font color=\"red\"><b>Failed to Connect to Server</b></font></td>" >> output.txt
                return;
        #elif grep -q "/tmp/check.sh.x: No such file or directory" failtmp.txt; then
	elif grep -q "/tmp/check_test.sh: No such file or directory" failtmp.txt; then
		printf "<td align=\"center\"><font color=\"red\"><b>Could not find Before Reboot Check Results</b></font></td>" >> output.txt
		return;
	else
		sed -i '1,/END OF PRE/d' result.txt
		[ -s result.txt ] || echo "<td><font color=\"red\"><b>Could not Fetch any Results, Please check OS</b></font></td>" >> result.txt
                #result=$(cat result.txt)
                #OLDIFS=$IFS
                #IFS=$'\n'
                #for line in $result
                #do
                #        printf "<td>$line</td>" >> output.txt
                #done
                #IFS=$OLDIFS
		printf "$(cat result.txt)" >> output.txt
        fi

	cat failtmp.txt >> fail.txt
	rawoutputformat
}

rawoutputformat()
{
echo "<!DOCTYPE html>" >> raw_output_${i}.html
echo "<html>" >> raw_output_${i}.html
echo "<head>" >> raw_output_${i}.html
   echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" >> raw_output_${i}.html
   echo "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">" >> raw_output_${i}.html
   echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js\"></script>" >> raw_output_${i}.html
   echo "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>" >> raw_output_${i}.html
echo "</head>" >> raw_output_${i}.html
echo "<body>" >> raw_output_${i}.html

echo "<div class=\"container\">" >> raw_output_${i}.html
  echo "<h2>Server Name - $i</h2>" >> raw_output_${i}.html
  echo "<p><strong>Note:</strong> Click on any link below to view related data for the Server</p>" >> raw_output_${i}.html
  echo "<div class=\"panel-group\" id=\"accordion\">" >> raw_output_${i}.html

  filecount=0
  for files in `ls -p /tmp/Pre_Logs/${i}/ | grep -v /` 
  do
    ((filecount++))
    sed -i 's/</<\\/' /tmp/Pre_Logs/${i}/${files}
    sed -i 's/$/<br><br>/' /tmp/Pre_Logs/${i}/${files}
    echo "<div class=\"panel panel-default\">" >> raw_output_${i}.html
      echo "<div class=\"panel-heading\">" >> raw_output_${i}.html
        echo "<h4 class=\"panel-title\">" >> raw_output_${i}.html
          echo "<a data-toggle=\"collapse\" data-parent=\"\#accordion\" href=\"\#collapse${filecount}\">$files</a>" >> raw_output_${i}.html
        echo "</h4>" >> raw_output_${i}.html
      echo "</div>" >> raw_output_${i}.html
      echo "<div id=\"collapse${filecount}\" class=\"panel-collapse collapse\">" >> raw_output_${i}.html
        echo "<div class=\"panel-body\">$(cat /tmp/Pre_Logs/${i}/${files})</div>" >> raw_output_${i}.html
      echo "</div>" >> raw_output_${i}.html
    echo "</div>" >> raw_output_${i}.html
    sed -i 's/<\\/</' /tmp/Pre_Logs/${i}/${files}
    sed -i 's/<br><br>//g' /tmp/Pre_Logs/${i}/${files}
  done

  echo "</div>" >> raw_output_${i}.html
echo "</div>" >> raw_output_${i}.html
    
echo "</body>" >> raw_output_${i}.html
echo "</html>" >> raw_output_${i}.html
chmod 666 raw_output_${i}.html
}

### Main Function ###

for i in $SERVERS
do
	printf "<tr>" >> output.txt
	
	if [[ $CHOICE = *reboot* ]]; then
		printf "<td><a href=\"http://10.235.9.181/REBOOT_BACKUPS/raw_output_${i}.html\">$i</a></td>" >> output.txt		
	else
		printf "<td>$i</td>" >> output.txt	
	fi

	for ch in $CHOICE
	do
		${ch}check
	done

	printf "</tr>" >> output.txt

done

printf "$(cat output.txt)\n"
