#!/bin/bash
userid="a373384"
paswd="BeAst135"
for server in `cat /var/www/html/ClusterStatus/cluster-nodes.txt`
do
echo "$server"
sshpass -p "$paswd" scp -q -p -o StrictHostKeyChecking=no -o ConnectTimeout=2 $userid@$server:/tmp/cluster-check.txt /var/www/html/ClusterStatus/data/$server.txt
done
Date=`date`
echo "<h4 align=left>Last Refresh: $Date</h4>" > /var/www/html/ClusterStatus/last-refresh.html

##copy data dir and last-refresh time to segotl4089.got.volvo.net###
sshpass -p "$paswd" scp -q -pr -o StrictHostKeyChecking=no -o ConnectTimeout=2 /var/www/html/ClusterStatus/data /var/www/html/ClusterStatus/last-refresh.html $userid@segotl4089.got.volvo.net:/var/www/html/ClusterStatus
