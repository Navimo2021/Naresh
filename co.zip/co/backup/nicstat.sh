echo "${BOLD}NETWORK MONITOR${RESET}"
echo -e "==================== \n"
rpm -qa | grep iftop*
if [[ ! $? = 0 ]]; then
 echo -e "Seems iftop package not installed  please install it and then check the statistics \n"
else
facter interfaces > /tmp/nics
cat /tmp/nics | sed 's/,/ /g' | fmt -1 | grep -v lo > /tmp/device
# _ check on file
cat /tmp/device | sed 's/_/:/g' > /tmp/virtnic
NIC1=/tmp/virtnic

cat $NIC1 |
while read line
do
  echo "DEVICE: $line"
  iftop -i $line -s 5 -t > /tmp/iftop$line.txt 2>&1
  cat /tmp/iftop$line.txt
 done
fi

