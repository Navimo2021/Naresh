#!/bin/bash

service cman start
service modclusterd start
service rgmanager start
fence_tool join
cman_tool join

