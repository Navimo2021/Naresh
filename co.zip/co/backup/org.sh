 #!/bin/bash
rm -rf output.txt
rm -rf failed_hosts.txt
rm -rf fail.txt
echo -n "Enter your VCN Domain Password:  >"
read -s PASSWORD
echo $'\n'
for i in `cat hostname.txt`
do
echo "Connecting to $i"
echo "$i" : >> output.txt

sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no $i "
/sbin/ifconfig -a | grep inet | grep -v inet6 " >> output.txt 2>> fail.txt
sshpass -p $PASSWORD ssh -n -o StrictHostKeyChecking=no $i "
netstat -nrv " >> output.txt 2>> fail.txt
if [ $? -ne 0 ]; then
        echo "$i" >> failed_hosts.txt
        echo "Failed for $i"
else
        echo "Done for $i"
fi

done

