#!/bin/bash
RED=`tput setaf 1`
RESET=`tput sgr0`
GREEN=`tput setaf 2`
BLUE=`tput setaf 4`
BOLD=`tput bold`
#Check User is root

USER=`whoami`

if ! [[ $USER = root ]]; then
echo "Run $0 as root user"
exit 1
else
#Collect System Information

echo -e "################################################################## \n"

echo -e "       ${BOLD}SYSTEM INFORMATION${RESET}    \n"
HOST=`facter fqdn`
VENDOR=`facter manufacturer`
SERVER_MODEL=`facter productname`
SERIAL_NUMBER=`facter serialnumber`
CPU_MODEL=`facter processor0`
VERSION=`facter lsbdistdescription`
KERNEL=`facter kernelrelease`
CPU=`lscpu | grep -w "^CPU(s)" | awk -F ":" '{print $2}' | awk -F " " '{print $1}'`
MEMORY=`facter memorysize`
SWAP=`facter swapsize`
SELINUX=`facter selinux_current_mode`
echo "${BLUE}HOSTNAME${RESET}:$HOST"
echo "${BLUE}VENDOR${RESET}:$VENDOR"
echo "${BLUE}SERVER_MODEL${RESET}:$SERVER_MODEL"
echo "${BLUE}SERIAL_NUMBER${RESET}:$SERIAL_NUMBER"
echo "${BLUE}CPU_MODEL${RESET}:$CPU_MODEL"
echo "${BLUE}OS${RESET}:$VERSION"
echo "${BLUE}KERNEL${RESET}:$KERNEL"
echo "${BLUE}CPU COUNT${RESET}:$CPU"
echo "${BLUE}MEMORY${RESET}:$MEMORY"
echo "${BLUE}SWAP${RESET}:$SWAP"
echo -e "${BLUE}SELINUX MODE${RESET}:$SELINUX \n"

echo -e "################################################################## \n"

#check uptime of the server

echo  "${BOLD}UPTIME DETAILS${RESET}"
echo -e "============== \n"
UP=`facter system_uptime`
echo -e  "$UP \n"

#Last Patch date and time

echo  "${BOLD}LAST PATCH DATE AND TIME${RESET}"
echo -e "========================= \n"

RHEL_VERSION=`facter lsbmajdistrelease`
if [[ $RHEL_VERSION = 7 ]]; then
 PATCH_DATE_RHEL7=`rpm -qa --last | egrep -w kernel-3* | head -1 | awk  '{print $2,$3,$4,$5,$6,$7}'`
 echo -e "$PATCH_DATE_RHEL7 \n"
elif [[ $RHEL_VERSION = 6 ]]; then
 PATCH_DATE_RHEL6=`rpm -qa --last | egrep -w kernel-2* | head -1 | awk  '{print $2,$3,$4,$5,$6,$7}'`
 echo -e "$PATCH_DATE_RHEL6 \n"
fi


#Check the NIC status

echo "${BOLD}NIC SPEED AND STATUS${RESET}"
echo -e "==================== \n"
facter interfaces > /tmp/nics
cat /tmp/nics | sed 's/,/ /g' | fmt -1 | grep -v lo > /tmp/device
NIC=/tmp/device
# _ check on file
cat /tmp/device | grep -i "_" > /tmp/aliasnic
VIRT_NIC=/tmp/aliasnic
   if ! [ -z "$VIRT_NIC" ]; then
      NIC1=`cat /tmp/device | sed 's/_/:/g'`
      for i in $NIC1
      do
        echo  "DEVICE: $i"
        ethtool $i | egrep -w 'Speed'
        NIC_STATUS=`ethtool $i| egrep -w "Link detected" | awk -F ":" '{print $2}'| awk -F " " '{print $1}'`
          if  [[ $NIC_STATUS = yes ]];then
            echo "        LINK Status:${GREEN}UP$RESET"
          elif [[ $NIC_STATUS = no ]];then
           echo -e "        LINK Status:${RED}DOWN$RESET\n"
          fi
        done
      fi

echo -e "\n"

##IP Details

echo "${BOLD}IP SUBNETMASK MAC DETAILS${RESET}"
echo -e "========================= \n"
FILE=/tmp/device
cat $FILE |
while read line
do
 echo  "DEVICE: $line"
 IP=`facter ipaddress_$line`
 SUBNET_MASK=`facter netmask_$line`
 MAC_ADDRESS=`facter macaddress_$line`
 MTU_SIZE=`facter mtu_$line`
 echo -e "IP=$IP SubnetMask=$SUBNET_MASK MacAddress=$MAC_ADDRESS MTU=$MTU_SIZE \n"
done

# Check the status of the Gateway

echo "${BOLD}GATEWAY CHECK${RESET}"
echo -e "============= \n"
VAR=`ip r | grep  ^default | awk -F " " '{print $3}'`
#IP address REGEX
REGEX="[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"

#REGEX CHECK
if  [[ $VAR =~ $REGEX ]]; then
IP=${BASH_REMATCH[0]}
ping -c4 $IP > /dev/null
if [ ! $? -eq 0 ]; then
   echo -e "Gateway $VAR ${RED}not reachable${RESET}. Please troubleshoot further. \n"
 else
   echo -e "Gateway $VAR ${GREEN}Reachable${RESET} \n"
fi
fi

#check DNS resolution

echo  "${BOLD}DNS CHECK${RESET}"
echo -e "========= \n"
nslookup ${HOST}
 if [ $? -eq 0 ]; then
   echo -e "DNS Resolution is ${GREEN}Success${RESET} \n"
   else
   echo -e "DNS Resolution ${RED} Failed ${RESET} \n"
 fi


# check Memory swap and cpu utilisation

echo "${BOLD}MEMORY SWAP AND CPU UTILIZATION${RESET}"
echo -e "=============================== \n"
MEM_TOTAL=`cat /proc/meminfo | grep -i MemTotal | awk -F " " '{print $2}'`
MEM_FREE=`cat /proc/meminfo | grep -i MemFree | awk -F " " '{print $2}'`
MEM_USED=`cat /proc/meminfo | grep -i MemAvailable | awk -F " " '{print $2}'`
echo -e "Total Memory=$(expr $MEM_TOTAL / 1024)MB" "Used=$(expr $MEM_USED / 1024)MB" "Free=$(expr $MEM_FREE / 1024)MB \n"
SWAP_TOTAL=`cat /proc/meminfo | grep -i SwapTotal | awk -F " " '{print $2}'`
SWAP_FREE=`cat /proc/meminfo | grep -i SwapFree | awk -F " " '{print $2}'`
SWAP_USED=$(expr $SWAP_TOTAL - $SWAP_FREE)
echo -e "Total SWAP=$(expr $SWAP_TOTAL / 1024)MB" "Used=$(expr $SWAP_USED / 1024)MB" "Free=$(expr $SWAP_FREE / 1024)MB \n"
CPU_USER=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $2}'`
CPU_SYSTEM=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $5}'`
CPU_IDLE=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $8}'`
CPU_WAIT=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $11}'`
CPU_STEAL=`top -n 1 | grep -w ^%Cpu | awk -F ":" '{print $2}' | awk -F "," '{print $1,$2,$4,$5,$8}' |awk -F " " '{print $14}'`
echo -e "CPU user utilisation=$CPU_USER% CPU system utilisation=$CPU_SYSTEM% CPU free=$CPU_IDLE% \n"
echo -e "IOWAIT=$CPU_WAIT% CPU STEAL=$CPU_STEAL% \n"
echo "${RED}NOTE${RESET}: More IO Wait and CPU steal will cause performance issues"
echo -e "!!!!Please investigate further if you see more IO wait and CPU steal on server!!!! \n"

# Check NTP sync
echo "${BOLD}NTP CHECK${RESET}"
echo -e "=========== \n"
OS_VERSION=`facter lsbmajdistrelease`
if [[ $OS_VERSION = 7 ]]; then
 chronyc sources
 echo -e "\n"
 echo "M/S column indicates the mode/state of the source".
 echo " ^ means a server, = means a peer and # indicates a locally connected reference clock."
 echo "* indicates the source to which chronyd is current synchronised. + indicates other acceptable sources."
 echo "? indicates sources to which connectivity has been lost.x indicates a clock which chronyd thinks is is a falseticker."
 echo -e "~ indicates a source whose time appears to have too much variability. \n"
 chronyc tracking
 echo -e "\n"
else
 ntpq -pn
 echo -e "\n"
 echo "* indicates the source to which chronyd is current synchronised. + indicates other acceptable sources."
 echo "? indicates sources to which connectivity has been lost.x indicates a clock which chronyd thinks is is a falseticker."
 echo -e "~ indicates a source whose time appears to have too much variability. \n"
fi

NTP_SYNC=`ntpstat | grep -w synchronised | awk -F " " '{ print $1}'`
if [[ ! NTP_SYNC = synchronised ]]; then
  echo  -e "NTP is ${GREEN}synchronised${RESET} \n"
else
  echo -e "NTP is ${RED}not synchronised${RESET} \n"
fi

#IPC- Message Queue shared memory  Semaphore check

echo  "${BOLD}IPC - MESSAGE QUEUE, SHARED MEMORY, SEMAPHORE STATUS${RESET}"
echo  "==================================================== "
IPC=`ipcs -u`
echo -e "$IPC \n"
echo -e "${RED}NOTE${RESET}: Please cross check the maximum limit using the command ipcs -l \n"


#Check for readonly FS
echo "${BOLD}READONLY FILESYSTEM CHECK${RESET}"
echo -e "========================== \n"
READONLY_FS=`cat /proc/mounts | grep ro, | grep -v "tmpfs"`
if [[ ! -z ${READONLY_FS} ]]; then
 echo -e "${RED}Readonly Filesystem${RESET} Found \n"
 echo  "${READONLY_FS}"
else
 echo -e "${GREEN}No Readonly Filesystem${RESET} on Server \n"
fi



# Load Average
echo  "${BOLD}LOAD AVERAGE OF LAST 15 MINUTES${RESET}"
echo -e "=============================== \n"
LOAD=`cat /proc/loadavg | awk -F " " '{print $3}'`
echo -e "Load:$LOAD \n"

#LOAD CHECK
LOAD1=`cat /proc/loadavg | awk -F " " '{print $3}'| awk -F "." '{print $1}'`
if [[ $LOAD1 -gt $CPU ]]; then
 echo -e "${RED}LOAD IS HIGHER${RESET} than amount of CPU cores we have on the server.\n"
else
 echo -e "Load is ${GREEN}normal${RESET} \n"
fi

#Display Top process consuming more CPU

CPU_PROCESS=`ps -eo pcpu,pid,user,args | head -1 ; ps -eo pcpu,pid,user,args | sort -nk 1 -r | head -10`

echo -e "${BOLD}TOP 10 PROCESSES CONSUMING CPU${RESET}"
echo -e "============================== \n"
echo -e "$CPU_PROCESS \n"

#Check active ( running ) and queued processes
echo  "${BOLD}Active ( running ) and queued (blocked D-state) processes${RESET}"
echo -e "========================================================= \n"
VMSTAT=`vmstat 1 10 > /tmp/vmstat.txt`
sleep 5
echo -e " `cat /tmp/vmstat.txt` \n"
RUNQUEUE_COUNT=`cat /tmp/vmstat.txt | awk 'BEGIN{FS= " "} {print $1 " "  $2}'  | grep -v ^procs | awk 'END{print $1}'`
BLOCKED_COUNT=`cat /tmp/vmstat.txt | awk 'BEGIN{FS= " "} {print $1 " "  $2}'  | grep -v ^procs | awk 'END{print $2}'`
echo -e "PROCESSES in RunQueue = $RUNQUEUE_COUNT  ${RED}BLOCKED${RESET} Process = $BLOCKED_COUNT\n"
 if [[ $RUNQUEUE_COUNT -gt $CPU ]]; then
   echo "${RED}NOTE${RESET}:If Run queue value is above installed CPU cores,  Please monitor continuously and investigate further."
   echo "    If Load average is high and no processes are being actively running and if you see more  Blocked process (D State)"
   echo -e "    then its time to review Storage performance or verification of any OS component like NFS/NIC/HBA etc \n"
 fi
QUEUE_PROCESS=`ps -eo stat,pid,user,command | egrep "^STAT|^D|^R"`
echo -e "$QUEUE_PROCESS \n"

#Display Top processes consuming memory

MEMORY_PROCESS=`ps aux  | awk '{print $6/1024 " MB\t\t" $11}'  | sort -nr | head -10`
echo -e "${BOLD}TOP 10 PROCESSES CONSUMING MEMORY${RESET}"
echo -e "================================= \n"
echo -e "$MEMORY_PROCESS \n"

#Display total number of process running by each users

echo  "${BOLD}TOTAL NUMBER OF PROCESSES RUNNING BY EACH USER${RESET}"
echo  -e "=============================================== \n"
TOTAL_PROCESS=`ps h -Led -o user | sort | uniq -c | sort -nr`
echo -e "$TOTAL_PROCESS \n"
echo "${RED}NOTE${RESET}:Please cross check the user limit in /etc/security/limits.conf file or under /etc/security/limits.d/ directory "
echo -e "Application may face problem  if the application user has reached its process limit. \n"

echo "${BOLD}IO MONITOR${RESET}"
echo -e "============= \n"
rpm -qa | grep iotop
if [[ ! $? = 0 ]]; then
 echo -e "Seems iotop package not installed  please install it and then check the statistics \n"
else
 echo -e "show  processes  or threads actually doing I/O \n"
 iotop -botqqqk --iter=10 > /tmp/iotop.txt
 cat /tmp/iotop.txt
 echo -e "\n"
fi


echo "${BOLD}NETWORK MONITOR${RESET}"
echo -e "================ \n"
rpm -qa | grep iftop
if [[ ! $? = 0 ]]; then
 echo -e "Seems iftop package not installed  please install it and then check the statistics \n"
else
facter interfaces > /tmp/nics
cat /tmp/nics | sed 's/,/ /g' | fmt -1 | grep -v lo > /tmp/device
# _ check on file
cat /tmp/device | sed 's/_/:/g' > /tmp/virtnic
NIC1=/tmp/virtnic

cat $NIC1 |
while read line
do
  echo "DEVICE: $line"
  iftop -i $line -s 5 -t > /tmp/iftop$line.txt 2>&1
  cat /tmp/iftop$line.txt
 done
fi

fi

