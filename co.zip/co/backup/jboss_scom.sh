#!/bin/ksh
VL_TMP_FILE=/tmp/scom_jboss.log
#rm -f ${VL_TMP_FILE}
#/usr/bin/PGS_batchrun -o /usr/libexec/soepostgresql/bin/PGS_mon_004.ksh p2 -o  1 all > ${VL_TMP_FILE}
sudo -H -u jboss /bin/bash -c "/opt/jboss/monitoring/jas_monitoring.sh" >> ${VL_TMP_FILE}
chmod o+rw ${VL_TMP_FILE}
exit 0
