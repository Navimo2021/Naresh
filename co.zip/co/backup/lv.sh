#!/bin/bash
echo "Enter the mount point name"
read MOUNTPOINT
lsblk  |grep "$MOUNTPOINT" |awk '{print $1}'| cut --complement -c 1-2 |cut -d "-" -f 2 > /tmp/lvname
SEGTYPE=$(for i in `cat /tmp/vgname`; do lvs --segments |grep $i |awk '{print $5}'; done)
lsblk  |grep "$MOUNTPOINT" |awk '{print $1}'| cut --complement -c 1-2 |cut -d "-" -f 1 > /tmp/vgname
VGFREE=$(for i in `cat /tmp/vgname`; do vgs $i |awk '{print $7}' |grep -iv vfree; done)
echo "The segment type of $MOUNTPOINT is $SEGTYPE"
FSTYPE=$(df -ThP $MOUNTPOINT |awk '{print $2}' |tail -1)
echo "The File system type of $MOUNTPOINT is $FSTYPE"
echo "Availbale Free space $VGFREE"
echo "Enter the size: Ex:(500M, 10G, 12T)"
read SIZE
if [ $FSTYPE = xfs ]
then
   lvextend -L +$SIZE /dev/`cat /tmp/vgname`/`cat /tmp/lvname`
   xfs_growfs /dev/`cat /tmp/vgname`/`cat /tmp/lvname`
else
   lvextend -L +$SIZE /dev/`cat /tmp/vgname`/`cat /tmp/lvname` -r
fi


