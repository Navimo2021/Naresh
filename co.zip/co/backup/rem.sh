#!/bin/bash
cd /tmp/stgiostat/tmp
ls | grep 2016 > output.txt
ls | grep 2017-04 >> output.txt
ls | grep 2017-05 >> output.txt
ls | grep 2017-06 >> output.txt

while read name; do
  rm "$name"
done < output.txt

