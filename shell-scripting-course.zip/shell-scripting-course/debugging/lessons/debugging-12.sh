#!/bin/bash

#DEBUG="echo"
$DEBUG ls
