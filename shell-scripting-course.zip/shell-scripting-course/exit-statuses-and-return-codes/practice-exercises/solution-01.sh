#!/bin/bash

echo "This script will exit with a 0 exit status."
exit 0
