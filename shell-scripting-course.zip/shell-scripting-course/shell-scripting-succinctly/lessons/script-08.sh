#!/bin/bash
MY_SHELL="bash"
echo "I am $MY_SHELLing on my keyboard."
