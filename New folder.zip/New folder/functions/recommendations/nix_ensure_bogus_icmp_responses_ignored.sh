#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendation/nix_ensure_bogus_icmp_responses_ignored.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/21/20    Recommendation "Ensure bogus ICMP responses are ignored"
#
nix_ensure_bogus_icmp_responses_ignored()
{
	echo "- $(date +%d-%b-%Y' '%T) - Starting $RNA" | tee -a "$LOG" 2>> "$ELOG"
	test="" test1="" test2=""
	# Check sysctl net.ipv4.icmp_ignore_bogus_error_responses in the running config
	echo "- $(date +%d-%b-%Y' '%T) - Checking sysctl net.ipv4.icmp_ignore_bogus_error_responses in the running config" | tee -a "$LOG" 2>> "$ELOG"
	if sysctl net.ipv4.icmp_ignore_bogus_error_responses | grep -Eq '^net.ipv4.icmp_ignore_bogus_error_responses\s*=\s+1\b'; then
		test1=passed
	else
		echo "- $(date +%d-%b-%Y' '%T) - Remediating net.ipv4.icmp_ignore_bogus_error_responses in the running config" | tee -a "$LOG" 2>> "$ELOG"
		sysctl -w net.ipv4.icmp_ignore_bogus_error_responses=1
		sysctl -w net.ipv4.route.flush=1
		sysctl net.ipv4.icmp_ignore_bogus_error_responses | grep -Eq '^net.ipv4.icmp_ignore_bogus_error_responses\s*=\s+1\b' && test1=remediated
	fi
	# Check sysctl net.ipv4.icmp_echo_ignore_broadcasts in sysctl conf files
	echo "- $(date +%d-%b-%Y' '%T) - Checking net.ipv4.icmp_ignore_bogus_error_responses in sysctl conf files" | tee -a "$LOG" 2>> "$ELOG"
	if ! grep -Elqs "^\s*net\.ipv4\.icmp_ignore_bogus_error_responses\s*=\s*0" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf; then
		test2=passed
	else
		echo "- $(date +%d-%b-%Y' '%T) - Remediating net.ipv4.icmp_echo_ignore_broadcasts in sysctl conf files" | tee -a "$LOG" 2>> "$ELOG"
		grep -Els "^\s*net\.ipv4\.icmp_ignore_bogus_error_responses\s*=\s*0" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf | while read -r filename; do
			sed -ri "s/^\s*(net\.ipv4\.icmp_ignore_bogus_error_responses\s*=\s*\S+\b).*$/# *REMOVED by CIS-LBK* \1/" "$filename"
		done
		! grep -Elqs "^\s*net\.ipv4\.icmp_ignore_bogus_error_responses\s*=\s*0" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf && test2=remediated
	fi
	if [ -n "$test1" ] && [ -n "$test2" ]; then
		if [ "$test1" = passed ] && [ "$test2" = passed ]; then
			test=passed
		else
			test=remediated
		fi
	fi
#	grep -Eq "^(\s*)net.ipv4.icmp_ignore_bogus_error_responses\s*=\s*\S+(\s*#.*)?\s*$" /etc/sysctl.conf && sed -ri "s/^(\s*)net.ipv4.icmp_ignore_bogus_error_responses\s*=\s*\S+(\s*#.*)?\s*$/\1net.ipv4.icmp_ignore_bogus_error_responses = 1\2/" /etc/sysctl.conf || echo "net.ipv4.icmp_ignore_bogus_error_responses = 1" >> /etc/sysctl.conf

	case "$test" in
		passed)
			echo "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		*)
			echo "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}